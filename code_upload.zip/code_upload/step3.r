# tmp/sm variations
library(raster)
library(dplyr)
path <- 'H:/PAPER_2/v15/DATA/'
datvalue <- df2array(read.csv(paste0(path,'ONI.csv'),header=F)[,-1])[-c(1:618,847:852)]

ndd <- array();	nd <- array()
for(i in 1:(length(datvalue)/12)){
	print(i)
	dat <- datvalue[((i-1)*12+1):(i*12)]
	for(j in 1:8){
		if(dat[j]>=1 & dat[j+1]>=1 & dat[j+2]>=1 & dat[j+3]>=1 & dat[j+4]>=1){
			nd[j] <- 1
		}else if(dat[j]<=(-1) & dat[j+1]<=(-1) & dat[j+2]<=(-1) & dat[j+3]<=(-1) & dat[j+4]<=(-1)){
			nd[j] <- 2
		}else if(dat[j]>=0.5& dat[j+1]>=0.5  &
					dat[j+2]>=0.5  & dat[j+3]>=0.5  & dat[j+4]>=0.5  ){
			nd[j] <- 3
		}else if(dat[j]<=(-0.5) & dat[j+1]<=(-0.5) &
				dat[j+2]<=(-0.5) &dat[j+3]<=(-0.5)  & dat[j+4]<=(-0.5) ){
			nd[j] <- 4
		}else{nd[j] <- 0}
	}
	if(length(nd[-which(nd=='0')])=='0'){
		ifelse(length(which(nd=='0'))=='0',ndd[i] <- min(nd),ndd[i] <- 0)
	}else{
		ndd[i] <- min(nd[-which(nd=='0')])
	}
}

s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/PAPER_2/v15/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
path3 <- 'H:/PAPER_2/v15/STEP3/'

dTA <- read.csv('H:/PAPER_2/v15/STEP1/datall.csv',header=T)[,-c(1:(181+365),7482:8395)]%>%
			apply(1,fungap,6935*0.75,'interp')%>%apply(2,fun8)%>%t()
write.csv(dTA,paste0(path3,'dTA.csv'),row.names=F)
dSM <- read.csv('H:/PAPER_2/v15/STEP2/datall.csv',header=T)[,-c(1:(181+365),7482:7665)]%>%
			apply(1,fungap,6935*0.75,'interp')%>%apply(2,fun8)%>%t()
write.csv(dSM,paste0(path3,'dSM.csv'),row.names=F)

ta_tau <- read.csv('H:/PAPER_2/v15/STEP1/dat_tau.csv',header=T)
datta <- array(data=NA,dim=c(dim(dTA)[1],floor(dim(dTA)[2]/365)))
for(i in 1:(floor(dim(dTA)[2]/365)-1)){
    print(i)
    datta[,i] <- dTA[,((i-1)*365+1):(i*365+365)]%>%
					apply(1,mean,na.rm=T)%>%as.numeric()
}
write.csv(datta,paste0(path3,'datta.csv'),row.names=F)

sm_tau <- read.csv('H:/PAPER_2/v15/STEP2/dat_tau.csv',header=T)
datsm <- array(data=NA,dim=c(dim(dSM)[1],floor(dim(dSM)[2]/365)))
for(i in 1:(floor(dim(dSM)[2]/365)-1)){
    print(i)
    datsm[,i] <- dSM[,((i-1)*365+1):(i*365+365)]%>%
					apply(1,mean,na.rm=T)%>%as.numeric()
}
write.csv(datsm,paste0(path3,'datsm.csv'),row.names=F)

path3 <- 'H:/PAPER_2/v15/STEP3/'
ndd <- c(0, 3, 0, 3, 4,    3, 2, 4, 1, 2,    4, 0, 0, 3, 1,   4, 4, 3,0)
datta <- read.csv(paste0(path3,'datta.csv'),header=T)
datsm <- read.csv(paste0(path3,'datsm.csv'),header=T)
tanormal <- apply(datta[,which(ndd=='0')],1,mean,na.rm=T)%>%as.numeric()
taE1 <- apply(datta[,which(ndd=='1')],1,mean,na.rm=T)%>%as.numeric()-tanormal
taL2 <- apply(datta[,which(ndd=='2')],1,mean,na.rm=T)%>%as.numeric()-tanormal
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- taE1
values(s) <- ss
writeRaster(s,paste0(path3,'taE1.tif'),overwrite=T)
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- taL2
values(s) <- ss
writeRaster(s,paste0(path3,'taL2.tif'),overwrite=T)

smnormal <- apply(datsm[,which(ndd=='0')],1,mean,na.rm=T)%>%as.numeric()
smE1 <- apply(datsm[,which(ndd=='1')],1,mean,na.rm=T)%>%as.numeric()-smnormal
smL2 <- apply(datsm[,which(ndd=='2')],1,mean,na.rm=T)%>%as.numeric()-smnormal
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- smE1
values(s) <- ss
writeRaster(s,paste0(path3,'smE1.tif'),overwrite=T)
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- smL2
values(s) <- ss
writeRaster(s,paste0(path3,'smL2.tif'),overwrite=T)
