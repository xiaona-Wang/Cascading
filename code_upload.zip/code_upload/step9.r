# future tele
library(forecast)
library(raster)
library(Kendall)
library(dplyr)
library(zoo)
library(SiZer)
library(stringr)
library(pracma)
library(doSNOW)
library(doParallel)
library(parallel)
path <- 'F:/cmip/'
outpath1 <- 'F:/PAPER_2/V14/data/cmiptif/MRSOS/'
outpath2 <- 'F:/PAPER_2/V14/data/cmiptif/TAS/'
xpath <- list.files(path)
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('F:/PAPER_2/V14/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
dall <- as.data.frame(s,xy=T)
ninoid <- which(dall$x>(-170) & dall$x<(-120) & dall$y>(-5) & dall$y<5)
for(i in 1:length(xpath)){
	ysm <- list.files(paste0(path,xpath[i]),pattern='mrsos')
	yta <- list.files(paste0(path,xpath[i]),pattern='tas')
	for(j in 1:length(ysm)){
		print(c(i,j))
		dat <- brick(paste0(path,xpath[i],'/',ysm[j]))
		for(k in 1:dim(dat)[3]){
			if(substr(names(dat[[k]]),2,5)%>%as.numeric()>=2080){
				dir.create(paste0(outpath1,xpath[i]))
				writeRaster(dat[[k]]%>%fun25(1.00000002004088e+20)%>%rotate()%>%resample(s,method='bilinear')%>%crop(s),
							paste0(outpath1,xpath[i],"/",names(dat[[k]]),'_',
							substr(ysm[j],str_length(ysm[j])-38,str_length(ysm[j])-33),'.tif'),overwrite=T)
			}
		}
	}
	for(j in 1:length(yta)){
		print(c(i,j))
		dat <- brick(paste0(path,xpath[i],'/',yta[j]))
		for(k in 1:dim(dat)[3]){
			if(substr(names(dat[[k]]),2,5)%>%as.numeric()>=2080){
			dir.create(paste0(outpath2,xpath[i]))
			writeRaster(dat[[k]]%>%fun24(1.00000002004088e+20)%>%rotate()%>%resample(s,method='bilinear')%>%crop(s),
							paste0(outpath2,xpath[i],"/",names(dat[[k]]),'_',
							substr(yta[j],str_length(yta[j])-38,str_length(yta[j])-33),'.tif'),overwrite=T)
			}
		}
	}
}
pathTAS <- 'F:/PAPER_2/V14/data/cmiptif/TAS/'
pathMRSOS <- 'F:/PAPER_2/V14/data/cmiptif/MRSOS/'
xTAS <- list.files(pathTAS)
xMRSOS <- list.files(pathMRSOS)
for(i in 1:length(xTAS)){
	ifelse(i=='4'|i=='7',y <- list.files(paste0(pathTAS,xTAS[i]),pattern='126')[-c(1:547,1521,2982,4443,5904,7487:7670)],
						y <- list.files(paste0(pathTAS,xTAS[i]),pattern='126')[-c(1:546,7482:7665)])
	datTAS <- array(data=NA,dim=c(length(which(lulcid>0)),length(y)))
	datnino <- array(data=NA,dim=c(length(ninoid),length(y)))
	for(j in 1:length(y)){
		print(c(i,j))
		datTAS[,j] <- as.data.frame(raster(paste0(pathTAS,xTAS[i],'/',y[j])))[which(lulcid>0),1]
		datnino[,j] <- as.data.frame(raster(paste0(pathTAS,xTAS[i],'/',y[j])))[ninoid,1]
	}
	write.csv(datTAS,paste0('F:/PAPER_2/V14/step10/TAS_new/',xTAS[i],'_ssp126_TAS.csv'),row.names=F)
	write.csv(datnino,paste0('F:/PAPER_2/V14/step10/TAS_new/',xTAS[i],'_ssp126_nino.csv'),row.names=F)
	ifelse(i=='4'|i=='7',y <- list.files(paste0(pathTAS,xTAS[i]),pattern='585')[-c(1:547,1521,2982,4443,5904,7487:7670)],
						y <- list.files(paste0(pathTAS,xTAS[i]),pattern='585')[-c(1:546,7482:7665)])
	datTAS <- array(data=NA,dim=c(length(which(lulcid>0)),length(y)))
	datnino <- array(data=NA,dim=c(length(ninoid),length(y)))
	for(j in 1:length(y)){
		print(c(i,j))
		datTAS[,j] <- as.data.frame(raster(paste0(pathTAS,xTAS[i],'/',y[j])))[which(lulcid>0),1]
		datnino[,j] <- as.data.frame(raster(paste0(pathTAS,xTAS[i],'/',y[j])))[ninoid,1]
	}
	write.csv(datTAS,paste0('F:/PAPER_2/V14/step10/TAS_new/',xTAS[i],'_ssp585_TAS.csv'),row.names=F)
	write.csv(datnino,paste0('F:/PAPER_2/V14/step10/TAS_new/',xTAS[i],'_ssp585_nino.csv'),row.names=F)
	ifelse(i=='4'|i=='7',y <- list.files(paste0(pathMRSOS,xMRSOS[i]),pattern='126')[-c(1:547,1521,2982,4443,5904,7487:7670)],
						y <- list.files(paste0(pathMRSOS,xMRSOS[i]),pattern='126')[-c(1:546,7482:7665)])
	datMRSOS <- array(data=NA,dim=c(length(which(lulcid>0)),length(y)))
	for(j in 1:length(y)){
		print(c(i,j))
		datMRSOS[,j] <- as.data.frame(raster(paste0(pathMRSOS,xMRSOS[i],'/',y[j])))[which(lulcid>0),1]
	}
	write.csv(datMRSOS,paste0('F:/PAPER_2/V14/step10/MRSOS_new/',xMRSOS[i],'_ssp126_MRSOS.csv'),row.names=F)
	ifelse(i=='4'|i=='7',y <- list.files(paste0(pathMRSOS,xMRSOS[i]),pattern='585')[-c(1:547,1521,2982,4443,5904,7487:7670)],
						y <- list.files(paste0(pathMRSOS,xMRSOS[i]),pattern='585')[-c(1:546,7482:7665)])
	datMRSOS <- array(data=NA,dim=c(length(which(lulcid>0)),length(y)))
	for(j in 1:length(y)){
		print(c(i,j))
		datMRSOS[,j] <- as.data.frame(raster(paste0(pathMRSOS,xMRSOS[i],'/',y[j])))[which(lulcid>0),1]
	}
	write.csv(datMRSOS,paste0('F:/PAPER_2/V14/step10/MRSOS_new/',xMRSOS[i],'ssp585_MRSOS.csv'),row.names=F)
}
s2s <- function(x,y,sigth){
	y <- as.numeric(y)
	if(length(na.omit(y))=='0'|length(na.omit(x))=='0'|sd(y,na.rm=T)=='0'){
		out <- array(data=NA,dim=c(18,1))%>%as.matrix()
	}else{
		y <- na.interp(as.numeric(y))
		out <- fun4c(x%>%fun8()%>%as.numeric(),
						y%>%fun8()%>%as.numeric(),
						365,200,sigth)%>%as.matrix()
	}
	return(out)
}
TAS <- 'F:/PAPER_2/V14/step10/TAS_new/'
MRSOS <- 'F:/PAPER_2/V14/step10/MRSOS_new/'
xTAS <- list.files(TAS,pattern='TAS')
xMRSOS <- list.files(MRSOS,pattern='MRSOS')
xNINO <- list.files(TAS,pattern='nino')
xID <- substr(xTAS,1,str_length(xTAS)-15)
for(i in 1:length(unique(xID))){
	print(i)
	datta <- read.csv(paste0(TAS,xTAS[which(xID==unique(xID)[i])][1]),header=T)
	th <- read.csv('F:/PAPER_2/V14/STEP1/dat_thres.csv',header=T)%>%apply(2,unique)%>%as.numeric()
	datnino <- read.csv(paste0(TAS,xNINO[which(xID==unique(xID)[i])][1]),header=T)%>%apply(2,mean,na.rm=T)
	cl <- makeCluster(15)
	registerDoParallel(cl)
	ta126 <- foreach(x=1:dim(datta)[1],
					.combine='cbind',
					.export=c("datta","s2s","datnino","fun4c","correlation","cor365","na.interp","th"),
					.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
	) %dopar% {s2s(datnino,datta[x,],th[x])}
	stopCluster(cl)
	write.csv(ta126,paste0('F:/PAPER_2/V14/step11/',unique(xID)[i],'_TAS_126.csv'),row.names=F)
}
for(i in 1:length(unique(xID))){
	print(i)
	datta <- read.csv(paste0(TAS,xTAS[which(xID==unique(xID)[i])][2]),header=T)
	th <- read.csv('F:/PAPER_2/V14/STEP1/dat_thres.csv',header=T)%>%apply(2,unique)%>%as.numeric()
	datnino <- read.csv(paste0(TAS,xNINO[which(xID==unique(xID)[i])][2]),header=T)%>%apply(2,mean,na.rm=T)
	cl <- makeCluster(15)
	registerDoParallel(cl)
	ta585 <- foreach(x=1:dim(datta)[1],
					.combine='cbind',
					.export=c("datta","s2s","datnino","fun4c","correlation","cor365","na.interp","th"),
					.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
	) %dopar% {s2s(datnino,datta[x,],th[x])}
	stopCluster(cl)
	write.csv(ta585,paste0('F:/PAPER_2/V14/step11/',unique(xID)[i],'_TAS_585.csv'),row.names=F)
}
for(i in 1:length(unique(xID))){
	print(i)
	datsm <- read.csv(paste0(MRSOS,xMRSOS[which(xID==unique(xID)[i])][1]),header=T)
	th <- read.csv('F:/PAPER_2/V14/STEP2/dat_thres.csv',header=T)%>%apply(2,unique)%>%as.numeric()
	datnino <- read.csv(paste0(TAS,xNINO[which(xID==unique(xID)[i])][1]),header=T)%>%apply(2,mean,na.rm=T)
	cl <- makeCluster(15)
	registerDoParallel(cl)
	sm126 <- foreach(x=1:dim(datsm)[1],
					.combine='cbind',
					.export=c("datsm","s2s","datnino","fun4c","correlation","cor365","na.interp","th"),
					.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
	) %dopar% {s2s(datnino,datsm[x,],th[x])}
	stopCluster(cl)
	write.csv(sm126,paste0('F:/PAPER_2/V14/step11/',unique(xID)[i],'_MRSOS_126.csv'),row.names=F)
}
for(i in 1:length(unique(xID))){
	print(i)
	datsm <- read.csv(paste0(MRSOS,xMRSOS[which(xID==unique(xID)[i])][2]),header=T)
	th <- read.csv('F:/PAPER_2/V14/STEP2/dat_thres.csv',header=T)%>%apply(2,unique)%>%as.numeric()
	datnino <- read.csv(paste0(TAS,xNINO[which(xID==unique(xID)[i])][2]),header=T)%>%apply(2,mean,na.rm=T)
	cl <- makeCluster(15)
	registerDoParallel(cl)
	sm585 <- foreach(x=1:dim(datsm)[1],
					.combine='cbind',
					.export=c("datsm","s2s","datnino","fun4c","correlation","cor365","na.interp","th"),
					.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
	) %dopar% {s2s(datnino,datsm[x,],th[x])}
	stopCluster(cl)
	write.csv(sm585,paste0('F:/PAPER_2/V14/step11/',unique(xID)[i],'_MRSOS_585.csv'),row.names=F)
}

path <- 'F:/PAPER_2/V14/step11/'
outpath <- 'F:/PAPER_2/V14/step12/'
x <- list.files(path,pattern='.csv')
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('F:/PAPER_2/V14/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
for(i in 1:length(x)){
	print(i)
	dat <- read.csv(paste0(path,x[i]),header=T)
	dat_wn <- apply(dat,2,fun11,-1)%>%as.numeric()
	dat_wp <- apply(dat,2,fun11,1)%>%as.numeric()
	ss <- rep(NA,length(s))
	ss[which(lulcid>0)] <- dat_wn
	values(s) <- ss
	writeRaster(s,paste0(outpath,substr(x[i],1,str_length(x[i])-4),'_wn.tif'),overwrite=T)
	ss <- rep(NA,length(s))
	ss[which(lulcid>0)]<- dat_wp
	values(s) <- ss
	writeRaster(s,paste0(outpath,substr(x[i],1,str_length(x[i])-4),'_wp.tif'),overwrite=T)
}

path <- 'F:/PAPER_2/V14/step12/'
outpath <- 'F:/PAPER_2/V14/step13/'
xpath <- list.files(path,pattern='.tif')
xid <- substr(xpath,1,str_length(xpath)-11)
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('F:/PAPER_2/V14/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
for(i in 1:(length(unique(xid))/2)){
	print(i)
	y1 <- which(xid==unique(xid)[(i-1)*2+1])
	y2 <- which(xid==unique(xid)[i*2])
	MRSOS_126_wn <- as.data.frame(raster(paste0(path,xpath[y1][1])))[,1]%>%fun5(0.75)
	TAS_126_wn <- as.data.frame(raster(paste0(path,xpath[y2][1])))[,1]%>%fun5(0.75)
	MRSOS_126_wp <- as.data.frame(raster(paste0(path,xpath[y1][2])))[,1]%>%fun5(0.75)
	TAS_126_wp <- as.data.frame(raster(paste0(path,xpath[y2][2])))[,1]%>%fun5(0.75)
	MRSOS_585_wn <- as.data.frame(raster(paste0(path,xpath[y1][3])))[,1]%>%fun5(0.75)
	TAS_585_wn <- as.data.frame(raster(paste0(path,xpath[y2][3])))[,1]%>%fun5(0.75)
	MRSOS_585_wp <- as.data.frame(raster(paste0(path,xpath[y1][4])))[,1]%>%fun5(0.75)
	TAS_585_wp <- as.data.frame(raster(paste0(path,xpath[y2][4])))[,1]%>%fun5(0.75)
	ss <- rep(NA,length(s))
	ss1 <- rep(0,length(s))
	ss1[intersect(which(TAS_126_wn=='1'),which(MRSOS_126_wp=='1'))] <- 1
	ss2 <- rep(0,length(s))
	ss2[intersect(which(TAS_126_wp=='1'),which(MRSOS_126_wn=='1'))] <- 1
	ss3 <- rep(0,length(s))
	ss3[intersect(which(TAS_126_wp=='1'),which(MRSOS_126_wp=='1'))] <- 1
	ss4 <- rep(0,length(s))
	ss4[intersect(which(TAS_126_wn=='1'),which(MRSOS_126_wn=='1'))] <- 1
	datall <- data.frame(ss1=ss1,ss2=ss2,ss3=ss3,ss4=ss4)
	datall[which(apply(datall,1,sum)>1),]<-NA
	ss[which(datall$ss1=='1')] <- 1
	ss[which(datall$ss2=='1')] <- 2
	ss[which(datall$ss3=='1')] <- 3
	ss[which(datall$ss4=='1')] <- 4
	values(s) <- ss
	writeRaster(s,paste0(outpath,substr(unique(xid)[i*2],1,str_length(unique(xid)[i*2])-4),'_126_hot.tif'),overwrite=T)
	ss <- rep(NA,length(s))
	ss1 <- rep(0,length(s))
	ss1[intersect(which(TAS_585_wn=='1'),which(MRSOS_585_wp=='1'))] <- 1
	ss2 <- rep(0,length(s))
	ss2[intersect(which(TAS_585_wp=='1'),which(MRSOS_585_wn=='1'))] <- 1
	ss3 <- rep(0,length(s))
	ss3[intersect(which(TAS_585_wp=='1'),which(MRSOS_585_wp=='1'))] <- 1
	ss4 <- rep(0,length(s))
	ss4[intersect(which(TAS_585_wn=='1'),which(MRSOS_585_wn=='1'))] <- 1
	datall <- data.frame(ss1=ss1,ss2=ss2,ss3=ss3,ss4=ss4)
	datall[which(apply(datall,1,sum)>1),]<-NA
	ss[which(datall$ss1=='1')] <- 1
	ss[which(datall$ss2=='1')] <- 2
	ss[which(datall$ss3=='1')] <- 3
	ss[which(datall$ss4=='1')] <- 4
	values(s) <- ss
	writeRaster(s,paste0(outpath,substr(unique(xid)[i*2],1,str_length(unique(xid)[i*2])-4),'_585_hot.tif'),overwrite=T)
}
path <- 'F:/PAPER_2/V14/step13/'
x126 <- list.files(path,pattern='126')
x585 <- list.files(path,pattern='585')
dat126 <- array(data=NA,dim=c(205920,length(x126)))
dat585 <- array(data=NA,dim=c(205920,length(x126)))
for(i in 1:(length(x126))){
	print(i)
	dat126[,i] <- as.data.frame(raster(paste0(path,x126[i])))[,1]
	dat585[,i] <- as.data.frame(raster(paste0(path,x585[i])))[,1]
}
ya126 <- apply(dat126,1,fun24,1,2)%>%as.numeric()
ya585 <- apply(dat585,1,fun24,1,2)%>%as.numeric()
yb126 <- apply(dat126,1,fun24,2,2)%>%as.numeric()
yb585 <- apply(dat585,1,fun24,2,2)%>%as.numeric()
values(s) <- ya126
writeRaster(s,paste0(path,'which126.tif'),overwrite=T)
values(s) <- ya585
writeRaster(s,paste0(path,'which585.tif'),overwrite=T)
values(s) <- yb126
writeRaster(s,paste0(path,'num126.tif'),overwrite=T)
values(s) <- yb585
writeRaster(s,paste0(path,'num585.tif'),overwrite=T)

path <- 'F:/PAPER_2/V14/step12/'
x <- list.files(path,pattern='.csv')
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('F:/PAPER_2/V14/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
datall <- array(data=NA,dim=c(13,51376))
for(i in 1:length(x)){
	print(i)
	dat <- read.csv(paste0(path,x[i]),header=T)
	dat_wn <- apply(dat,2,fun11,-1)%>%as.numeric()
	dat_wp <- apply(dat,2,fun11,1)%>%as.numeric()
	ss <- rep(NA,length(s))
	ss[which(lulcid>0)] <- dat_wn
	values(s) <- ss
	writeRaster(s,paste0(path,substr(x[i],1,str_length(x[i])-4),'_wn.tif'),overwrite=T)
	ss <- rep(NA,length(s))
	ss[which(lulcid>0)]<- dat_wp
	values(s) <- ss
	writeRaster(s,paste0(path,substr(x[i],1,str_length(x[i])-4),'_wp.tif'),overwrite=T)
}

path <- 'F:/PAPER_2/V14/step12/'
outpath <- 'F:/PAPER_2/V14/step13/'
xpath <- list.files(path,pattern='.tif')
xid <- substr(xpath,1,str_length(xpath)-10)
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('F:/PAPER_2/V14/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
for(i in 1:(length(xpath)/4)){
	print(i)
	MRSOS_126_wn <- as.data.frame(raster(paste0(path,xpath[(i-1)*4+3])))[,1]%>%fun5(0.75)
	TAS_126_wn <- as.data.frame(raster(paste0(path,xpath[(i-1)*4+1])))[,1]%>%fun5(0.75)
	MRSOS_126_wp <- as.data.frame(raster(paste0(path,xpath[(i-1)*4+4])))[,1]%>%fun5(0.75)
	TAS_126_wp <- as.data.frame(raster(paste0(path,xpath[(i-1)*4+2])))[,1]%>%fun5(0.75)
	ss <- rep(NA,length(s))
	ss1 <- rep(0,length(s))
	ss1[intersect(which(TAS_126_wn=='1'),which(MRSOS_126_wp=='1'))] <- 1
	ss2 <- rep(0,length(s))
	ss2[intersect(which(TAS_126_wp=='1'),which(MRSOS_126_wn=='1'))] <- 1
	ss3 <- rep(0,length(s))
	ss3[intersect(which(TAS_126_wp=='1'),which(MRSOS_126_wp=='1'))] <- 1
	ss4 <- rep(0,length(s))
	ss4[intersect(which(TAS_126_wn=='1'),which(MRSOS_126_wn=='1'))] <- 1
	datall <- data.frame(ss1=ss1,ss2=ss2,ss3=ss3,ss4=ss4)
	datall[which(apply(datall,1,sum)>1),]<-NA
	ss[which(datall$ss1=='1')] <- 1
	ss[which(datall$ss2=='1')] <- 2
	ss[which(datall$ss3=='1')] <- 3
	ss[which(datall$ss4=='1')] <- 4
	values(s) <- ss
	writeRaster(s,paste0(outpath,substr(xpath[(i-1)*4+1],1,str_length(xpath[(i-1)*4+1])-10),'_hot.tif'),overwrite=T)
}
path <- 'F:/PAPER_2/V14/step13/'
x <- list.files(path)
dat <- array(data=NA,dim=c(205920,length(x)))
for(i in 1:length(x)){
	print(i)
	dat[,i] <- as.data.frame(raster(paste0(path,x[i])))[,1]
}
ya <- apply(dat,1,fun24,1,2)%>%as.numeric()
values(s) <- ya
writeRaster(s,paste0(path,'ya.tif'),overwrite=T)

path <- 'F:/PAPER_2/v14/step1/'
outpath <- 'F:/PAPER_2/V14/step14/'
nino <- read.csv(paste0(path,'nino.csv'),header=T)[1:5110,1]
datta <- read.csv(paste0(path,'datall.csv'),header=T)[,1:5110]
datsm <- read.csv(paste0('F:/PAPER_2/v14/step2/datall.csv'),header=T)[,1:5110]
th <- read.csv('F:/PAPER_2/V14/STEP1/dat_thres.csv',header=T)%>%apply(2,unique)%>%as.numeric()
s2s <- function(x,y,sigth){
	y <- as.numeric(y)
	if(length(na.omit(y))=='0'|length(na.omit(x))=='0'|sd(y,na.rm=T)=='0'){
		out <- array(data=NA,dim=c(13,1))%>%as.matrix()
	}else{
		y <- na.interp(as.numeric(y))
		out <- fun4c(x,y%>%fun8()%>%as.numeric(),365,200,sigth)%>%as.matrix()
	}
	return(out)
}
cl <- makeCluster(15)
registerDoParallel(cl)
ta <- foreach(x=1:dim(datta)[1],
				.combine='cbind',
				.export=c("datta","s2s","nino","fun4a","correlation","cor365","na.interp"),
				.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
) %dopar% {s2s(nino,datta[x,],th[x])}
stopCluster(cl)
write.csv(ta,paste0(outpath,'datta.csv'),row.names=F)
cl <- makeCluster(15)
registerDoParallel(cl)
sm <- foreach(x=1:dim(datsm)[1],
				.combine='cbind',
				.export=c("datsm","s2s","nino","fun4a","correlation","cor365","na.interp"),
				.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
) %dopar% {s2s(nino,datsm[x,],th[x])}
stopCluster(cl)
write.csv(sm,paste0(outpath,'datsm.csv'),row.names=F)
outpath <- 'F:/PAPER_2/V14/step14/'
datta <- read.csv(paste0(outpath,'datta.csv'),header=T)
datsm <- read.csv(paste0(outpath,'datsm.csv'),header=T)
datta_wn <- apply(datta,2,fun11,-1)%>%as.numeric()
datta_wp <- apply(datta,2,fun11,1)%>%as.numeric()
datsm_wn <- apply(datsm,2,fun11,-1)%>%as.numeric()
datsm_wp <- apply(datsm,2,fun11,1)%>%as.numeric()
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- datta_wn
values(s) <- ss
writeRaster(s,paste0(outpath,'datta_wn.tif'),overwrite=T)
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- datta_wp
values(s) <- ss
writeRaster(s,paste0(outpath,'datta_wp.tif'),overwrite=T)
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- datsm_wn
values(s) <- ss
writeRaster(s,paste0(outpath,'datsm_wn.tif'),overwrite=T)
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- datsm_wp
values(s) <- ss
writeRaster(s,paste0(outpath,'datsm_wp.tif'),overwrite=T)
ta_wn <- as.data.frame(raster(paste0(outpath,'datta_wn.tif')))[,1]%>%fun5(0.75)
ta_wp <- as.data.frame(raster(paste0(outpath,'datta_wp.tif')))[,1]%>%fun5(0.75)
sm_wn <- as.data.frame(raster(paste0(outpath,'datsm_wn.tif')))[,1]%>%fun5(0.75)
sm_wp <- as.data.frame(raster(paste0(outpath,'datsm_wp.tif')))[,1]%>%fun5(0.75)
ss <- rep(NA,length(s))
ss1 <- rep(0,length(s))
ss1[intersect(which(ta_wn=='1'),which(sm_wp=='1'))] <- 1
ss2 <- rep(0,length(s))
ss2[intersect(which(ta_wp=='1'),which(sm_wn=='1'))] <- 1
ss3 <- rep(0,length(s))
ss3[intersect(which(ta_wp=='1'),which(sm_wp=='1'))] <- 1
ss4 <- rep(0,length(s))
ss4[intersect(which(ta_wn=='1'),which(sm_wn=='1'))] <- 1
datall <- data.frame(ss1=ss1,ss2=ss2,ss3=ss3,ss4=ss4)
datall[which(apply(datall,1,sum)>1),]<-NA
ss[which(datall$ss1=='1')] <- 1
ss[which(datall$ss2=='1')] <- 2
ss[which(datall$ss3=='1')] <- 3
ss[which(datall$ss4=='1')] <- 4
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_hot.tif'),overwrite=T)
