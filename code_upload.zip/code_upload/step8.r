# pathway
library(raster)
library(Kendall)
library(dplyr)
library(zoo)
library(SiZer)
library(stringr)
library(pracma)
library(doSNOW)
library(doParallel)
path <- 'F:/newera5/wind/'
x <- list.files(path)
s <- raster(nrow=360,ncol=720)
outpath <- 'F:/PAPER_2/v14/data/wind/'
for(i in 1:length(x)){
	print(i)
	prebru <- brick(paste0(path,x[i]),varname='u')
	for(j in 1:dim(prebru)[3]){
		dat <- rotate(prebru[[prebru@data@names[j],exact=F]])
		dvalue <- resample(dat,s,method='bilinear')
		writeRaster(dvalue,paste0(outpath,'u/',prebru@data@names[j],'.tif'),overwrite=T)
	}
	prebrv <- brick(paste0(path,x[i]),varname='v')
	for(j in 1:dim(prebrv)[3]){
		dat <- rotate(prebrv[[prebrv@data@names[j],exact=F]])
		dvalue <- resample(dat,s,method='bilinear')
		writeRaster(dvalue,paste0(outpath,'v/',prebrv@data@names[j],'.tif'),overwrite=T)
	}
}
pathu <- 'F:/PAPER_2/v14/data/wind/u/'
pathv <- 'F:/PAPER_2/v14/data/wind/v/'
patht <- 'F:/PAPER_2/v14/data/t2m/'
path8 <- 'F:/PAPER_2/v14/step8/'
xu <- list.files(pathu)[-c(1:547,1521,2982,4443,5904,7365,7488:8401)]
xv <- list.files(pathv)[-c(1:547,1521,2982,4443,5904,7365,7488:8401)]
xt <- list.files(patht)[-c(1:547,1521,2982,4443,5904,7365,7488:8401)]
datu <- array(data=NA,dim=c(36*72,length(xu)))
datv <- array(data=NA,dim=c(36*72,length(xv)))
datt <- array(data=NA,dim=c(36*72,length(xt)))
s <- raster(nrow=36,ncol=72)
for(i in 1:length(xu)){
	print(i)
	datu[,i] <- as.data.frame(resample(raster(paste0(pathu,xu[i])),s,method='bilinear'))[,1]
	datv[,i] <- as.data.frame(resample(raster(paste0(pathv,xv[i])),s,method='bilinear'))[,1]
	datt[,i] <- as.data.frame(resample(raster(paste0(patht,xt[i])),s,method='bilinear'))[,1]
}
write.csv(datu,paste0(path8,'datu.csv'),row.names=F)
write.csv(datv,paste0(path8,'datv.csv'),row.names=F)
write.csv(datt,paste0(path8,'datt.csv'),row.names=F)

library(dplyr)
ndd <- c(0, 3, 0, 3, 4,  3, 2, 4, 1, 2,  4, 0, 0, 3, 1,  4, 4, 3)
path8 <- 'F:/PAPER_2/v14/step8/'
datu <- read.csv(paste0(path8,'datu.csv'),header=T)
datv <- read.csv(paste0(path8,'datv.csv'),header=T)
lu <- array();lv <- array()
eu <- array();ev <- array()
nu <- array();nv <- array()
allu <- array();allv <- array()
for(i in 1:dim(datu)[1]){
	print(i)
	u <- datu[i,]%>%as.numeric()
	v <- datv[i,]%>%as.numeric()
	du <- array();dv <- array()
	for(j in 1:floor(length(u)/365)){
		du[j] <- u[((j-1)*365+1):(j*365)]%>%mean(na.rm=T)
		dv[j] <- v[((j-1)*365+1):(j*365)]%>%mean(na.rm=T)
	}
	lu[i] <- mean(du[which(ndd=='2')],na.rm=T)
	lv[i] <- mean(dv[which(ndd=='2')],na.rm=T)
	eu[i] <- mean(du[which(ndd=='1')],na.rm=T)
	ev[i] <- mean(dv[which(ndd=='1')],na.rm=T)
	nu[i] <- mean(du[which(ndd=='0')],na.rm=T)
	nv[i] <- mean(dv[which(ndd=='0')],na.rm=T)
	allu[i] <- mean(du,na.rm=T)
	allv[i] <- mean(dv,na.rm=T)
}
s <- raster(nrow=36,ncol=72)
values(s) <- allu
writeRaster(s,paste0(path8,'allu.tif'),overwrite=T)
values(s) <- allv
writeRaster(s,paste0(path8,'allv.tif'),overwrite=T)
values(s) <- lu
writeRaster(s,paste0(path8,'lu.tif'),overwrite=T)
values(s) <- lv
writeRaster(s,paste0(path8,'lv.tif'),overwrite=T)
values(s) <- eu
writeRaster(s,paste0(path8,'eu.tif'),overwrite=T)
values(s) <- ev
writeRaster(s,paste0(path8,'ev.tif'),overwrite=T)

s <- raster(nrow=36,ncol=72)
ss <- as.data.frame(s,xy=T)
nino34 <- which(ss$x>-170 & ss$x<(-120) & ss$y>-5 & ss$y<5)
bm <- which(ss$x==(-122.5) & ss$y==47.5)
nm <- which(ss$x==(-52.5) & ss$y==2.5)
tp <- which(ss$x==87.5  &  ss$y==( 27.5))
path8 <- 'F:/PAPER_2/v14/step8/'
datera <- read.csv(paste0(path8,'datt.csv'),header=T)%>%apply(1,fun8)
cl <- makeCluster(15)
registerDoParallel(cl)
dat_link <- foreach(x=1:dim(datera)[2],
				.combine='rbind',
				.export=c("datera","funlink","link","correlation","cor365","fun4a"),
				.packages=c("zoo","dplyr","doParallel","doSNOW","parallel")
) %dopar% {funlink(x,72,365,200,0,datera)}
stopCluster(cl)
write.csv(dat_link,'F:/PAPER_2/v14/step8/dat_link.csv',row.names=F)

library(igraph)
library(raster)
path8 <- 'F:/PAPER_2/v14/step8/'
dat_link <- read.csv(paste0(path8,'dat_link.csv'),header=T)%>%na.omit()%>%as.data.frame()
colnames(dat_link) <- c('m','y','link')
yyy <- c('tp')
dat_link$link <- abs(dat_link$link)
ta <- add_edges(make_empty_graph(dim(dat_link)[1]), t(dat_link[, 1:2]), weight = dat_link[, 3])
for(j in nino34){
for(i in 1:length(yyy)){
	yyt <- get(yyy[i])
	if(length(yyt)>0){
		for(k in yyt){
			rs <- tryCatch(shortest_paths(ta,j,k,algorithm='dijkstra')$vpath[[1]]%>%as.numeric()%>%fun14(36,72),
								error=function(e){c(NA,NA)})
			if(dim(rs)[1]>0){
			dir.create(paste0(path8,yyy[i]))
			write.csv(rs,paste0(path8,yyy[i],'/dat_',i,'_',j,'.csv'),row.names=F)}
		}
	}
}}
