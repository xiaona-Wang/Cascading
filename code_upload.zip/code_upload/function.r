# functions used in the study
fungap <- function(x,y,method){
	library(forecast)
	library(zoo)
	library(Rssa)
	x <- as.numeric(x)
	if(length(na.omit(x))<y){
		z <- rep(NA,length(x))
	}else if(length(na.omit(x))==length(x)){
		z <- x
	}else{
		if(method=='interp'){
			z <- na.interp(x)
		}else if(method=='spline'){
			z <- na.spline(x)
		}else if(method=='ssa'){
			z <- gapfill(ssa(x,L=floor(length(x)/2.5)), groups = list(1:6))
		}
	}
	return(z)
}

funcyclecal <- function(x,y){
	xx <- as.numeric(x)
	dim(xx) <- c(y,length(xx)/y)
	dat <- rep(apply(xx,1,mean,na.rm=T)%>%as.numeric(),length(x)/y)
	return(as.numeric(x)-dat)
}

leap <- function(x){
    if(x%%4==0){
        if(((x%%100==0)&(x%%400==0))|(x%%100!=0))
            print(TRUE) else
                print(FALSE)
    } else
        print(FALSE)
}

mon2day <- function(x,y){
	d31 <- c('01','03','05','07','08','10','12')
	d30 <- c('04','06','09','11')
	if(leap(y)){
	if(x %in% d31){z <- '31'}else if(x %in% d30){z <- '30'}else{z <- '29'}
	}else{
	if(x %in% d31){z <- '31'}else if(x %in% d30){z <- '30'}else{z <- '28'}
	}
	return(z)
}

errorcal <- function(x){
	if(length(na.omit(x))=="0"){
	r1<-NA;r2<-NA}else{
	r1 <- mean_na(x)+2*sd_na(x)
	r2 <- mean_na(x)-2*sd_na(x)
	}
	return(c(r1,r2))
}

func1_v2 <- function(x){
	y <- array()
	for(i in 1:dim(x)[1]){
		y[((i-1)*dim(x)[2]+1):(i*dim(x)[2])] <- as.numeric(x[i,])
	}
	return(y)
}

dflen <- function(x,y){
	x <- as.data.frame(x)
	if(y<length(x[,1])){
		z<-x
	}else{
		dat <- array(data=NA,dim=c(y-dim(x)[1],dim(x)[2]))
		colnames(dat) <- colnames(x)
		z <- rbind(x,dat)
	}
	return(as.data.frame(z))
}

dnumlen <- function(x,y){
	x <- as.numeric(x)
	if(y<length(x)){
		z<-x
	}else{
		z <- c(x,rep(NA,y-length(x)))
	}
	return(z)
}

datefun <- function(x,y){
	y <- as.numeric(y)
	x <- as.numeric(x)
	dat <- array()
	for(i in 1:(y-x+1)){
		for(j in 1:12){
			dat[(i-1)*12+j] <- paste0(x+(i-1),formatC(j,flag='0',width=2))
		}
	}
	return(as.numeric(dat))
}

funar1 <- function(ts,wl){
	l <- length(ts)
	ar1_ts <- rep(NA, l-wl+1)
	for (i in 1:(l-wl+1)) {
		ar1_ts[i] <- ar.ols(ts[i:(i+wl-1)], aic=FALSE, order.max=1)$ar
	}
	return(ar1_ts)
}

correlation <- function(Ti,Tj,taumax,window){
	if(taumax>length(Ti)) stop('taumax too max！')
	if(length(na.omit(Tj))=='0'){
		output<-NA
	}else{
		cv_i2j<-array();cv_j2i<-array()
		for(i in 1:taumax){
			Ti_d <- Ti[1:window]
			Tj_d_tau <- Tj[(i+1):(window+i)]
			cv_i2j[i] <- (mean(Ti_d*Tj_d_tau)-mean(Ti_d)*mean(Tj_d_tau))/(((mean((Ti_d-mean(Ti_d))^2))^0.5)*((mean((Tj_d_tau-mean(Tj_d_tau))^2))^0.5))
		}
		cv_ij <- (mean(Ti*Tj)-mean(Ti)*mean(Tj))/(((mean((Ti-mean(Ti))^2))^0.5)*((mean((Tj-mean(Tj))^2))^0.5))
		for(i in 1:taumax){
			Tj_d <- Tj[1:window]
			Ti_d_tau <- Ti[(i+1):(window+i)]
			cv_j2i[i] <- (mean(Tj_d*Ti_d_tau)-mean(Tj_d)*mean(Ti_d_tau))/(((mean((Tj_d-mean(Tj_d))^2))^0.5)*((mean((Ti_d_tau-mean(Ti_d_tau))^2))^0.5))
		}
		cv <- c(rev(cv_j2i),cv_ij,cv_i2j)
		dat <- data.frame(tau=((-taumax):taumax),cv=cv)
		tau0 <- dat[which.max(abs(cv)),1]
		cc <- dat[which.max(abs(cv)),2]
		ww <- (cc-mean(cv))/sd(cv)
		ifelse(tau0>0,inj <- 1,inj <- 0)
		output <- list()
		output$corvalue <- dat
		ifelse(tau0=='NaN',output$tau0 <-NA,output$tau0 <-tau0)
		ifelse(inj=='NaN',output$n <-NA,output$n <-inj)
		ifelse(inj*cc=='NaN',output$c <-NA,output$c <-inj*cc)
		ifelse(inj*ww=='NaN',output$w <-NA,output$w <-inj*ww)
	}
	return(output)
}

cor365 <- function(Ti,Tj){
	ifelse(length(na.omit(Tj))=='0',cv_ij <- NA,
			cv_ij <- (mean(Ti*Tj)-mean(Ti)*mean(Tj))/(((mean((Ti-mean(Ti))^2))^0.5)*((mean((Tj-mean(Tj))^2))^0.5)))
	return(cv_ij)
}

fun3 <- function(x){
	x <- as.numeric(x)
	x[which(x<0)]<-NA
	return(x)
}

fun3a <-function(x,y){
	x <- as.numeric(x)
	ifelse(sd(x)>y,x<-rep(NA,length(x)),x<-x)
	return(x)
}

fun3b <- function(x){
	x <- as.numeric(x)
	x[which(x>(mean(x,na.rm=T)+2*sd(x,na.rm=T)))]<-NA
	x[which(x<(mean(x,na.rm=T)-2*sd(x,na.rm=T)))]<-NA
	return(x)
}

fun3c <- function(x,y){
	x <- as.numeric(x)
	x[which(x==y)]<-NA
	return(x)
}

fun4a <- function(x,y,z1,z2){
	x <- as.numeric(x);y <- as.numeric(y)
	if(length(na.omit(y) | na.omit(x))=='0' | sd(y)=='0'){
		out <- array(NA,dim=c(floor(length(x)/z1)-1,5))
	}else{
		corc <- array();corw <- array();corn <- array();cortau <- array()
		for(i in 1:(floor(length(x)/z1)-1)){
			cor <- correlation(x[((i-1)*z1+1):(i*z1+z1)],y[((i-1)*z1+1):(i*z1+z1)],z2,z1)
			if (is.null(cor$c) || is.null(cor$n) || is.null(cor$w) || is.na(cor$c) || is.na(cor$n) || is.na(cor$w)){
				corc[i] <- NA;corw[i] <- NA;corn[i] <- NA;cortau[i]<- NA
			}else{
				corc[i] <- cor$c;corw[i] <- cor$w;corn[i] <- cor$n;cortau[i]<-cor$tau0
			}
		}
		cortestc <- array()
		for(i in 1:100){
			set.seed(i)
			id <- sample(1:(length(x)-z1),1)
			cortestc[i] <- cor365(x[id:(id+z1-1)],y[id:(id+z1-1)])
		}
		cortestc[which(cortestc=='NaN')]<-NA
		thres <- quantile(na.omit(abs(cortestc)),0.95)%>%as.numeric()
		seqs <- which(abs(corc)>thres)
		corc[-seqs]<-NA;corw[-seqs]<-NA;corn[-seqs]<-NA ;cortau[-seqs]<-NA
		out <- data.frame(corc=corc,corn=corn,corw=corw,cortau=cortau,corthre=thres)
	}
	return(out)
}

fun4c <- function(x,y,z1,z2,sigth){
	x <- as.numeric(x);y <- as.numeric(y)
	if(length(na.omit(y) | na.omit(x))=='0'){
		out <- NA
	}else{
		corc <- array();corw <- array()
		for(i in 1:(floor(length(x)/z1)-1)){
			cor <- correlation(x[((i-1)*z1+1):(i*z1+z1)],y[((i-1)*z1+1):(i*z1+z1)],z2,z1)
			if(length(cor$c | cor$n | cor$w)=='0'){
				corc[i] <- NA;corw[i] <- NA;
			}else{
				corc[i] <- cor$c;corw[i] <- cor$w;
			}
		}
		seqs <- which(abs(corc)>sigth)
		corc[-seqs]<-NA;corw[-seqs]<-NA;
		out <- corw
	}
	return(out)
}

fun4 <- function(x,y,z){
	corc <- array();corw <- array();corn <- array()
	for(i in 1:dim(y)[1]){
		cor <- correlation(x,as.numeric(y[i,]),z,365)
		corc[i] <- cor$c
		corw[i] <- cor$w
		corn[i] <- cor$n
	}
	out <- data.frame(c=corc,w=corw,n=corn)
	return(out)
}

fun5 <- function(x,threshold){
	x <- as.numeric(x)
	xx <- abs(x)
	xx[which(xx=='0')]<-NA
	th <- quantile(xx,threshold,na.rm=T)
	y <- rep(NA,length(xx))
	y[which(xx>th)]<-1
	y[which(xx<th)]<-0
	return(y)
}

library(zoo)
fun6 <- function(x,z){
	library(dplyr)
	x <- as.numeric(x)
	if(length(na.omit(x))=='0'){
		x2 <- rep(NA,length(x))
	}else{
		x <- na.spline(x)
		x1 <- ts(x,frequency=z)%>%stl('periodic')
		x2 <- x1$time.series[,3]
	}
	return(x2)
}

fun7 <- function(x,m){
	x <- as.numeric(x)
	y <- array()
	for(i in 1:(length(x)-(m-1))){
		y[i] <- mean(x[i:(i+(m-1))])
	}
	return(y)
}

fun8 <- function(x){
	x <- as.numeric(x)
	y <- x-mean(x,na.rm=T)
	return(y)
}

fun8a <- function(x){
	x <- as.numeric(x)
	y <- abs(x-mean(x))/abs(mean(x))
	return(y)
}

fun8b <- function(x,y){
	x <- as.data.frame(x)
	y <- as.numeric(y)
	z <- array(data=NA,dim=c(dim(x)[1],365))
	for(i in 1:length(y)){
		if(is.na(y[i]) | (y[i]<0)){
			z[i,] <- rep(NA,365)
		}else{
			ifelse(y[i]=='0',z[i,] <- x[i,1:365]%>%as.numeric(),
								z[i,] <- x[i,y[i]:(y[i]+364)]%>%as.numeric())
		}
	}
	return(z)
}

fundis <- function(lon1,lat1,lon2,lat2){
	library(geosphere)
	dis <- distGeo( c(lon1,lat1), c(lon2,lat2) )
	return(dis)
}

fundate <- function(year, month, day){
	input_date <- as.Date(paste(year, month, day, sep="-"))
	reference_date <- as.Date("2000-01-01")
	days_difference <- as.numeric(difftime(input_date, reference_date, units = "days"))
	return(days_difference)
}

fun9 <- function(x,ninodat){
	x <- as.data.frame(x)
	xe <- x[which(ninodat=='1'),]
	xl <- x[which(ninodat=='2'),]
	ifelse(length(which(xe[,3]>0))>0,xe1 <- xe[which(xe[,3]>0),],xe1 <- rep(NA,4))
	ifelse(dim(xe1)[1]>1,xe2<- as.numeric(apply(xe1,2,sum)),xe2 <- as.numeric(xe1))
	ifelse(length(which(xl[,3]>0))>0,xl1 <- xl[which(xl[,3]>0),],xl1 <- rep(NA,4))
	ifelse(dim(xl1)[1]>1,xl2<- as.numeric(apply(2,sum)),xl2 <- as.numeric(xl1))
	output <- list()
	output$e <- xe2
	output$l <- xl2
	return(output)
}

fun10 <- function(x,y){
	x<-as.numeric(x)
	x1 <- mean(x[which(x>0)],na.rm=T)
	x2 <- mean(x[which(x<0)],na.rm=T)
	ifelse(y>0,out<-x1,out<-x2)
	return(out)
}
fun11 <- function(x,y){
	x<-as.numeric(x)
	x1 <- sum(x[which(x>0)],na.rm=T)
	x2 <- sum(x[which(x<0)],na.rm=T)
	ifelse(y>0,out<-x1,out<-x2)
	return(out)
}

fun11a <- function(x){
	y <- sum(as.numeric(x),na.rm=T)
	return(y)
}

fun11b <- function(x,y){
	x<-as.numeric(x)
	ifelse(y>0,x[which(x<0)]<-NA,x[which(x>0)]<-NA)
	return(x)
}

fun11c <- function(x,y){
	library(dplyr)
	x1 <- x[which(x>0)]
	x2 <- x[which(x<0)]
	ifelse(length(which(x1>y))==length(x1),z1<-1,z1<-0)
	ifelse(length(which(abs(x2)>y))==length(x2),z2<-1,z2<-0)
	return(c(z1,z2))
}

fun11d <- function(x){
	x <- x%>%abs()%>%as.numeric()%>%sum(na.rm=T)
	return(x)
}

fun11e <- function(x){
	x <- x%>%abs()%>%as.numeric()%>%mean(na.rm=T)
	return(x)
}

fun11f <- function(x,y){
	if(y>0){
		dat <- x[which(x>0)]%>%abs()%>%as.numeric()
		if(length(dat)>1){
			z <- dat%>%mean(na.rm=T)
		}else{
			z <- NA
		}
	}else{
		dat <- x[which(x<0)]%>%abs()%>%as.numeric()
		if(length(dat)>1){
			z <- dat%>%mean(na.rm=T)
		}else{
			z <- NA
		}
	}
	return(z)
}

fun11g <- function(x,y){
	if(y>0){
		dat <- x[which(x>0)]%>%abs()%>%as.numeric()
		if(length(dat)>1){
			z <- dat%>%sd(na.rm=T)
		}else{
			z <- NA
		}
	}else{
		dat <- x[which(x<0)]%>%abs()%>%as.numeric()
		if(length(dat)>1){
			z <- dat%>%sd(na.rm=T)
		}else{
			z <- NA
		}
	}
	return(z)
}

calCV <- function(x){
	x <- as.numeric(x)
	return(sd_na(x)/mean_na(x)*100)
}

fun12 <- function(x){
	library(trend)
	library(SiZer)
	library(segmented)
	x <- as.numeric(x)
	dats <- data.frame(value=x,time=1:length(x))
	fit <- lm(value~time,data=dats)
	slope <- summary(fit)[[4]][2,1]
	pvalue <- mk.test(x)$p.value
	segmented.fit <- segmented(fit, seg.Z = ~time)
	databreak <- summary(segmented.fit)[12][[1]][2]
	slope1 <- slope(segmented.fit)[[1]][1,1]
	slope2 <- slope(segmented.fit)[[1]][2,1]
	p1 <- mk.test(x[1:databreak])$p.value
	p2 <- mk.test(x[databreak:length(x)])$p.value
	out <- c(slope,pvalue,databreak,slope1,p1,slope2,p2)
	return(out)
}

fun12a <- function(x){
	library(trend)
	x <- as.numeric(x)
	if(length(na.omit(x))=='0'){
		z <- c(NA,NA)
	}else{
		slope <- sens.slope(x)$estimates[[1]]
		pvalue <- mk.test(x)$p.value
		z <- c(slope,pvalue)
	}
	return(z)
}

fun12b <- function(x){
	library(dplyr)
	x <- as.numeric(x)
	if(length(na.omit(x))=='0'){
		z <- c(NA,NA)
	}else{
		y<-cor.test(1:length(x),x,method='kendall')
		p <- y$p.value
		slope <- y$estimate%>%as.numeric()
		z <- c(slope,p)
	}
	return(z)
}

fun13 <- function(x){
	x <- as.numeric(x)
	y<- c(mean_na(x[1:31]),mean_na(x[32:59]),mean_na(x[60:90]),
			mean_na(x[91:120]),mean_na(x[121:151]),mean_na(x[152:181]),
			mean_na(x[182:212]),mean_na(x[213:243]),mean_na(x[244:273]),
			mean_na(x[274:304]),mean_na(x[305:334]),mean_na(x[335:365]))
	return(y)
}

link <- function(x,m,y){
	dat <- data.frame(m=rep(x,8),y=c( (floor(x/m)-1)*m+x%%m-1,
										(floor(x/m)-1)*m+x%%m,
										(floor(x/m)-1)*m+x%%m+1,
										x-1,
										x+1,
										(floor(x/m)+1)*m+x%%m-1,
										(floor(x/m)+1)*m+x%%m,
										(floor(x/m)+1)*m+x%%m+1
										))
	if(x<=m & x>=1){
		dat <- dat[-(1:3),]
	}else if(x<=dim(y)[1] & x>=(floor(x/m)*m+1) ){
		dat <- dat[-(6:8),]
	}else{dat <- dat}
	ifelse(length(which(dat$y>dim(y)[1] | dat$y<0))>0,
			dat <- dat[-which(dat$y>dim(y)[1] | dat$y<0),],
			dat <- dat)
	if(x%%m=='1'){
		dat$y[which(dat$y%%m=='0')] <- dat$y[which(dat$y%%m=='0')]+m
	}else if(x%%m=='0'){
		dat$y[which(dat$y%%m=='1')] <- dat$y[which(dat$y%%m=='1')]-m
	}
	return(dat)
}

linkerror <- function(x){
	x <- as.data.frame(x)
	for(i in 1:dim(x)[1]){
		ifelse(x[i,1]==x[i,2],x<-x[-i,],x<-x)
	}
	return(x)
}

funlink <- function(x,m,n,k,year,y){
	dat <- link(x,m,y)
	if(length(dat[,1])>0){
		for(i in 1:dim(dat)[1]){
			dat <- rbind(dat,data.frame(m=rep(dat[i,1],length(link(dat[i,2],m,y)[,2])),y=link(dat[i,2],m,y)[,2]))
		}
		dat <- dat%>%distinct(m,y)%>%linkerror()%>%subset(m<36*72&y<36*72)
		if(dim(dat)[1]=='0'){
			datqqq <- rep(NA,3)
		}else{
			linkss <- array(data=NA,dim=c(dim(dat)[1],5))
			for(i in 1:dim(dat)[1]){
				y1 <- y[,dat[i,1]]%>%as.numeric()
				y2 <- y[,dat[i,2]]%>%as.numeric()
				all <- fun4a(y1,y2,n,k)
				for(ii in 1:dim(all)[1]){
					all[ii,][which(all[ii,]%>%as.numeric()=='0')]<-NA
				}
				if(dim(na.omit(all))[1]=='0'){
					linkss[i,] <- rep(NA,5)
				}else{
					if(year=='0'){
						linkss[i,] <- all%>%apply(2,fun11e)%>%as.numeric()
					}else{
						linkss[i,] <- all[year,]%>%apply(2,fun11e)%>%as.numeric()
					}
				}
			}
			datqqq <- data.frame(dat,links=1/linkss[,3])%>%na.omit()%>%as.data.frame()
		}
	}else{
		datqqq <- rep(NA,3)
	}
	out <- datqqq
	return(out)
}

fun13a <- function(x){
	x <- as.numeric(x)
	y1 <- sum(x[which(x>0)])
	y2 <- sum(x[which(x<0)])
	return(c(y1,y2))
}

fun13b <- function(x){
	x <- as.numeric(x)
	y1 <- mean(x[which(x>0)])
	y2 <- mean(x[which(x<0)])
	return(c(y1,y2))
}

fun13c <- function(x,y){
	x <- as.numeric(x)
	y <- as.numeric(y)
	y1 <- mean(y[which(x>0)])
	y2 <- mean(y[which(x<0)])
	return(c(y1,y2))
}

fun14 <- function(x,rows,cols){
	library(raster)
	x <- as.numeric(x)
	s <- raster(nrow=rows,ncol=cols)
	ss <- as.data.frame(s,xy=T)
	lon <- ss[x,1];lat <- ss[x,2];
	return(data.frame(lon,lat))
}

fun15 <- function(x,window){
	x <- as.numeric(x)
	y1 <- array();y2 <- array();
	for(i in 1:floor(length(x)/window)){
		y1[i] <- mean(x[((i-1)*window+1):(i*window)])
		y2[i] <- sd(x[((i-1)*window+1):(i*window)])
	}
	y <- data.frame(mean=y1,sd=y2)
	return(y)
}

fun16 <- function(x){
	a <- c(10,  7,  8,  9,  3,  1,  5, 12, 14,  4,  6,  2)
	x <- as.numeric(x)
	z <- array()
	for(i in 1:12){
		z[i] <- length(which(x==a[i]))/length(na.omit(x))
	}
	zz <- c(sum(z[c(5,6,7,10,12)]),sum(z[c(2,3,4,11)]),sum(z[1]),sum(z[c(8,9)]))
	return(zz)
}

fun17 <- function(x){
	x <- as.numeric(na.omit(x))%>%abs()
	ifelse(length(x)=='0',y <- c(NA,NA),y <- c(which.max(x),x[which.max(x)]))
	return(y)
}

fun17a <- function(z,x){
	z <- as.data.frame(z)
	y <- array(data=NA,dim=c(dim(z)[1],2))
	for(i in 1:length(x)){
		if(is.na(x[i])){
			y[i,] <- c(NA,NA)
		}else if(x[i]=="1"){
			y[i,] <- z[i,c(2,3)]%>%as.numeric()
		}else if(x[i]=="2"){
			y[i,] <- z[i,c(1,4)]%>%as.numeric()
		}else if(x[i]=="3"){
			y[i,] <- z[i,c(1,3)]%>%as.numeric()
		}else if(x[i]=="4"){
			y[i,] <- z[i,c(2,4)]%>%as.numeric()
		}
	}
	return(y)
}

fun17b <- function(x){
	y <- as.numeric(abs(x))%>%sum()
		return(y)
}

fun17c <- function(x){
	x <- as.numeric(na.omit(x))%>%abs()
	ifelse(length(x)=='0',y <- c(NA,NA),y <- c(which.min(x),x[which.min(x)]))
	return(y)
}

fun18a <- function(x){
	ifelse(length(na.omit(x))=='2',y <- which.max(x),y <- NA)
	return(y)
}

fun18b <- function(x){
	ifelse(length(na.omit(x))=='2',y <- max(x),y <- NA)
	return(y)
}

fun19 <- function(x){
	x <- as.numeric(x)
	y <- length(na.omit(x))
	return(y)
}

df2array <- function(x){
	x <- as.matrix(x)
	y <- array()
	for(i in 1:dim(x)[1]){
		y[((i-1)*dim(x)[2]+1):(i*dim(x)[2])] <- x[i,]%>%as.numeric()
	}
	y <- as.numeric(y)
	return(y)
}

fun20 <- function(x){
	x <- as.matrix(x)
	ifelse(length(na.omit(x))>2,y<-sd(as.numeric(na.omit(x)))/mean(as.numeric(na.omit(x))),y<-NA)
	return(y)
}

funsss <- function(x){
	x <- as.numeric(x)
	return(length(na.omit(x)))
}

fun21 <- function(x,y){
	x <- as.data.frame(x)
	dat <- array(data=NA,dim=c(dim(x)[1],length(y)*365))
	for(i in 1:length(y)){
		dat[,((i-1)*365+1):(i*365)] <- x[,((y[i]-1)*365+1):(y[i]*365)]%>%as.matrix()
	}
	return(as.data.frame(dat))
}

fun22 <- function(x,y1,y2){
	x <- as.data.frame(x)
	dat <- array()
	for(i in 1:length(y)){
		dat[i] <- length(which(x[i,]<y1 | x[i,]>y2))/length(x[i,])
	}
	return(dat)
}

fun23 <- function(x,y,z){
	x <- as.data.frame(x)
	u <- x[which(y==z),]
	return(u)
}

fun24 <- function(x,num,threshold){
	x <- as.numeric(x)
	if(length(na.omit(x))<2){
		z1 <- NA; z2 <- NA
	}else{
		y <- as.data.frame(table(x))
		if(y$Freq[which.max(y$Freq)]%>%as.numeric()>=threshold){
			z1 <- y$x[[which.max(y$Freq)]]%>%as.character()%>%as.numeric()
			z2 <- length(na.omit(x))
		}else{
			z1 <- NA; z2 <- NA
		}
	}
	ifelse(num=='1',q<-z1,q<-z2)
	return(q)
}

fun25 <- function(x,y){
	dat <- as.data.frame(x)[,1]
	dat[which(dat==y)]<-NA
	values(x) <- dat
	return(x)
}

funfraction_v2 <- function(x,y){
	x <- as.numeric(na.omit(x))
	dat <- array()
	for(i in 1:y){
		dat[i] <- length(which(x==i))/length(x)
	}
	return(dat)
}

fun333 <- function(x){
	y <- array()
	for(i in 1:dim(x)[1]){
		y[((i-1)*dim(x)[2]+1):(i*dim(x)[2])] <- as.numeric(x[i,])
	}
	return(y)
}

fun26 <- function(x){
	x <- as.numeric(na.omit(x))
	x[which(x>(mean(x)+2*sd(x)) | x<(mean(x)-2*sd(x)))]<-NA
	return(x)
}

fun27 <- function(x,y){
	dat <- array()
	for(i in 1:length(unique(y))){
		dat[i] <- x[which(y==unique(y)[i])]%>%mean(na.rm=T)
	}
	return(dat)
}
