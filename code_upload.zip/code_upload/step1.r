# 1st path for tmp
library(raster)
library(Kendall)
library(dplyr)
library(zoo)
library(SiZer)
library(stringr)
library(pracma)
library(doSNOW)
library(doParallel)
library(parallel)
library(forecast)
path <- 'H:/ERA5/t2m/'
x <- list.files(path)
s <- raster(nrow=360,ncol=720)
outpath <- 'H:/PAPER_2/v15/DATA/t2m/'
for(i in 1:length(x)){
	print(i)
	prebr <- brick(paste0(path,x[i]),varname='t2m')
	for(j in 1:dim(prebr)[3]){
		dat <- rotate(prebr[[j]])
		datvalue <- as.data.frame(dat)[,1]
		datvalue[which(datvalue=='-32767')]<-NA
		values(dat) <- datvalue
		dvalue <- resample(dat,s,method='bilinear')
		writeRaster(dvalue,paste0(outpath,prebr@data@names[j],'.tif'),overwrite=T)
	}
}

path <- 'H:/PAPER_2/v15/DATA/t2m/'
outpath <- 'H:/PAPER_2/v15/step1/'
x <- list.files(path)[-c(60,1521,2982,4443,5904,7365)]
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/PAPER_2/v15/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
dall <- as.data.frame(s,xy=T)
ninoid <- which(dall$x>(-170) & dall$x<(-120) & dall$y>(-5) & dall$y<5)
datall <- array(data=NA,dim=c(length(which(lulcid>0)),length(x)))
datnino <- array(data=NA,dim=c(length(ninoid),length(x)))
for(i in 1:length(x)){
	print(i)
	datall[,i] <- as.data.frame(crop(raster(paste0(path,x[i])),lulc))[which(lulcid>0),1]
	datnino[,i] <- as.data.frame(crop(raster(paste0(path,x[i])),lulc))[ninoid,1]
}
write.csv(datnino,paste0(outpath,'datnino.csv'),row.names=F)
write.csv(datall,paste0(outpath,'datall.csv'),row.names=F)

path1 <- 'H:/PAPER_2/v15/step1/'
datnino <- read.csv(paste0(path1,'datnino.csv'),header=T)[,-c(1:(181+365),7482:8395)]
nino <- datnino%>%apply(2,mean)%>%fun8()%>%as.numeric()
write.csv(nino,paste0(path1,'nino.csv'),row.names=F)

outpath <- 'H:/PAPER_2/v15/step1/'
nino <- read.csv(paste0(outpath,'nino.csv'),header=T)[,1]
datall <- read.csv(paste0(outpath,'datall.csv'),header=T)[,-c(1:(181+365),7482:8395)]
s2s <- function(x,y){
	out <- fun4a(x, fungap(y,length(x)*0.75,'interp')%>%fun8()%>%as.numeric(),365,200)%>%as.matrix()
	return(out)
}
cl <- makeCluster(60)
registerDoParallel(cl)
dat <- foreach(x=1:dim(datall)[1],
				.combine='cbind',
				.export=c("datall","s2s","nino","fun4a","correlation","cor365","fungap"),
				.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
) %dopar% {s2s(nino,datall[x,])}
stopCluster(cl)
write.csv(dat,paste0(outpath,'dat.csv'),row.names=F)

path1 <- 'H:/PAPER_2/v15/step1/'
dat <- read.csv(paste0(path1,'dat.csv'),header=T)
write.csv(dat[,seq(1,dim(dat)[2],5)],paste0(path1,'dat_c.csv'),row.names=F)
write.csv(dat[,seq(2,dim(dat)[2],5)],paste0(path1,'dat_n.csv'),row.names=F)
write.csv(dat[,seq(3,dim(dat)[2],5)],paste0(path1,'dat_w.csv'),row.names=F)
write.csv(dat[,seq(4,dim(dat)[2],5)],paste0(path1,'dat_tau.csv'),row.names=F)
write.csv(dat[,seq(5,dim(dat)[2],5)],paste0(path1,'dat_thres.csv'),row.names=F)
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/PAPER_2/v15/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA

outpath <- 'H:/PAPER_2/v15/step1/'
dat <- read.csv(paste0(outpath,'dat_w.csv'),header=T)
dat_wn <- apply(dat,2,fun11,-1)%>%as.numeric()
dat_wp <- apply(dat,2,fun11,1)%>%as.numeric()
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_wn
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_wn.tif'),overwrite=T)
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_wp
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_wp.tif'),overwrite=T)

outpath <- 'H:/PAPER_2/v15/step1/'
dat <- read.csv(paste0(outpath,'dat_c.csv'),header=T)
dat_cn <- apply(dat,2,fun11,-1)%>%as.numeric()
dat_cp <- apply(dat,2,fun11,1)%>%as.numeric()
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_cn
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_cn.tif'),overwrite=T)
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_cp
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_cp.tif'),overwrite=T)

outpath <- 'H:/PAPER_2/v15/step1/'
dat <- read.csv(paste0(outpath,'dat_n.csv'),header=T)
dat_nn <- apply(dat,2,fun11a)%>%as.numeric()
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_nn
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_nn.tif'),overwrite=T)
