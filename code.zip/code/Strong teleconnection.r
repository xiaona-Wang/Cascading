# strong teleconnection nodes
library(raster)
library(dplyr)
outpath <- 'H:/step4/'
path1 <- 'H:/step1/'
path2 <- 'H:/step2/'
ta_wn <- as.data.frame(raster(paste0(path1,'dat_wn.tif')))[,1]%>%fun5(0.75)
ta_wp <- as.data.frame(raster(paste0(path1,'dat_wp.tif')))[,1]%>%fun5(0.75)
sm_wn <- as.data.frame(raster(paste0(path2,'dat_wn.tif')))[,1]%>%fun5(0.75)
sm_wp <- as.data.frame(raster(paste0(path2,'dat_wp.tif')))[,1]%>%fun5(0.75)
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
ss1 <- rep(0,length(s))
ss1[intersect(which(ta_wn=='1'),which(sm_wp=='1'))] <- 1
ss2 <- rep(0,length(s))
ss2[intersect(which(ta_wp=='1'),which(sm_wn=='1'))] <- 1
ss3 <- rep(0,length(s))
ss3[intersect(which(ta_wp=='1'),which(sm_wp=='1'))] <- 1
ss4 <- rep(0,length(s))
ss4[intersect(which(ta_wn=='1'),which(sm_wn=='1'))] <- 1
datall <- data.frame(ss1=ss1,ss2=ss2,ss3=ss3,ss4=ss4)
datall[which(apply(datall,1,sum,na.rm=T)%>%as.numeric()>1),]<-NA
ss <- rep(NA,length(s))
ss[which(datall$ss1=='1')] <- 1
ss[which(datall$ss2=='1')] <- 2
ss[which(datall$ss3=='1')] <- 3
ss[which(datall$ss4=='1')] <- 4
values(s) <- ss
writeRaster(s,paste0(outpath,'hot.tif'),overwrite=T)

path4 <- 'H:/step4/'
hot <- as.data.frame(raster(paste0(path4,'hot.tif')))[,1]
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/data/lulc/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
dat <- data.frame(lulcid=lulcid,hot=hot)%>%na.omit()%>%as.data.frame()
write.csv(dat,paste0(path4,'hottj.csv'),row.names=F)

datfra <- array(data=NA,dim=c(length(unique(dat$lulcid)),4))
for(i in 1:length(unique(dat$lulcid))){
	print(i)
	datfra[i,] <- dat$hot[which(dat$lulcid==unique(dat$lulcid)[i])]%>%
						funfraction_v2(4)
}
datfra <- datfra%>%as.data.frame()
colnames(datfra) <- c('hot1','hot2','hot3','hot4')
datfra$id <- unique(dat$lulcid)
write.csv(datfra,paste0(path4,'hottj2.csv'),row.names=F)

taseq <- c(-1,1,1,-1);smseq <- c(1,-1,1,-1)
taseqq <- c(1,-1,-1,1);smseqq <- c(-1,1,-1,1)
path4 <- 'H:/step4/'
hottj <- read.csv(paste0(path4,'hottj.csv'),header=T)
hot <- as.data.frame(raster(paste0(path4,'hot.tif')))[which(lulcid>0),1]
ndd <- c(0, 3, 0, 3, 4,   3, 2, 4, 1, 2,    4, 0, 0, 3, 1,   4, 4, 3,0 )
path1 <- 'H:/step1/'
path2 <- 'H:/step2/'
taw <- read.csv(paste0(path1,'dat_w.csv'),header=T)[,which(hot>0)]
smw <- read.csv(paste0(path2,'dat_w.csv'),header=T)[,which(hot>0)]

datata3 <- datasm3 <- datata4 <- datasm4 <- datata5 <- datasm5 <- datata6 <- datasm6 <- array(data=NA,dim=c(dim(taw)[1],4))
for(i in 1:length(unique(hottj[,2]))){
	datata3[,i] <- apply(taw[,which(hottj[,2]==sort(unique(hottj[,2]))[i])],1,fun11f,taseq[i])
	datata4[,i] <- apply(taw[,which(hottj[,2]==sort(unique(hottj[,2]))[i])],1,fun11g,taseq[i])
	datasm3[,i] <- apply(smw[,which(hottj[,2]==sort(unique(hottj[,2]))[i])],1,fun11f,smseq[i])
	datasm4[,i] <- apply(smw[,which(hottj[,2]==sort(unique(hottj[,2]))[i])],1,fun11g,smseq[i])

	datata5[,i] <- apply(taw[,which(hottj[,2]==sort(unique(hottj[,2]))[i])],1,fun11f,taseqq[i])
	datata6[,i] <- apply(taw[,which(hottj[,2]==sort(unique(hottj[,2]))[i])],1,fun11g,taseqq[i])
	datasm5[,i] <- apply(smw[,which(hottj[,2]==sort(unique(hottj[,2]))[i])],1,fun11f,smseqq[i])
	datasm6[,i] <- apply(smw[,which(hottj[,2]==sort(unique(hottj[,2]))[i])],1,fun11g,smseqq[i])
}
datall1 <- data.frame(datata3,datata4,datata5,datata6,
						datasm3,datasm4,datasm5,datasm6)
colnames(datall1) <- c('ta_1n_mean','ta_2p_mean','ta_3p_mean','ta_4n_mean',
						'ta_1n_sd','ta_2p_sd','ta_3p_sd','ta_4n_sd',
						'ta_1p_mean','ta_2n_mean','ta_3n_mean','ta_4p_mean',
						'ta_1p_sd','ta_2n_sd','ta_3n_sd','ta_4p_sd',
						'sm_1p_mean','sm_2n_mean','sm_3p_mean','sm_4n_mean',
						'sm_1p_sd','sm_2n_sd','sm_3p_sd','sm_4n_sd',
						'sm_1n_mean','sm_2p_mean','sm_3n_mean','sm_4p_mean',
						'sm_1n_sd','sm_2p_sd','sm_3n_sd','sm_4p_sd')
write.csv(datall1,paste0(path4,'datall.csv'),row.names=F)

taseq <- c(-1,1,1,-1);smseq <- c(1,-1,1,-1)
path4 <- 'H:/step4/'
hottj <- read.csv(paste0(path4,'hottj.csv'),header=T)
hot <- as.data.frame(raster(paste0(path4,'hot.tif')))[which(lulcid>0),1]
ndd <- c(0, 3, 0, 3, 4,   3, 2, 4, 1, 2,    4, 0, 0, 3, 1,   4, 4, 3,0 )
path1 <- 'H:/step1/'
path2 <- 'H:/step2/'
taw <- read.csv(paste0(path1,'dat_w.csv'),header=T)[,which(hot>0)]
smw <- read.csv(paste0(path2,'dat_w.csv'),header=T)[,which(hot>0)]
tasss <- array(data=NA,dim=c(5,4))
smsss <- array(data=NA,dim=c(5,4))
for(i in 1:5){
for(j in 1:4){
	print(i)
	tasss[i,j] <- taw[which(ndd==(i-1)),which(hot[which(hot>0)]==j)]%>%
					df2array()%>%na.omit()%>%abs()%>%mean(na.rm=T)
	smsss[i,j] <- smw[which(ndd==(i-1)),which(hot[which(hot>0)]==j)]%>%
					df2array()%>%na.omit()%>%abs()%>%mean(na.rm=T)
}}
datsss <- data.frame(tasss=tasss,smsss=smsss)
colnames(datsss) <- c('ta_hot1','ta_hot2','ta_hot3','ta_hot4',
							'sm_hot1','sm_hot2','sm_hot3','sm_hot4')
row.names(datsss) <- c('0','1','2','3','4')
write.csv(datsss,paste0(path4,'datsss.csv'),row.names=F)

path3 <- 'H:/step3/'
path4 <- 'H:/step4/'
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/data/lulc/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
hot <- as.data.frame(raster('H:/step4/hot.tif'))[which(lulcid>0),1]
taw <- read.csv(paste0(path1,'dat_w.csv'),header=T)[,which(hot>0)]
smw <- read.csv(paste0(path2,'dat_w.csv'),header=T)[,which(hot>0)]
datta <- read.csv('H:/step3/datta.csv',header=T)[which(hot>0),]%>%t()
datsm <- read.csv('H:/step3/datsm.csv',header=T)[which(hot>0),]%>%t()
d1ta <- data.frame(e1ta=fun23(datta,ndd,1)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs(),
					e3ta=fun23(datta,ndd,3)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs(),
					l2ta=fun23(datta,ndd,2)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs(),
					l4ta=fun23(datta,ndd,4)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs(),
					nta=fun23(datta,ndd,0)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs(),
					e1swc=fun23(datsm,ndd,1)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs(),
					e3swc=fun23(datsm,ndd,3)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs(),
					nswc=fun23(datsm,ndd,0)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs(),
					l2swc=fun23(datsm,ndd,2)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs(),
					l4swc=fun23(datsm,ndd,4)%>%apply(2,mean,na.rm=T)%>%df2array()%>%abs())
write.csv(d1ta,paste0(path4,'d1ta.csv'),row.names=F)
