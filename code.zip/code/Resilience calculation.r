# resilience calculation
library(raster)
library(stringr)
library(forecast)
library(lubridate)
library(Kendall)
library(dplyr)
library(zoo)
library(SiZer)
library(pracma)
library(doSNOW)
library(doParallel)
library(parallel)
path <- 'H:/FluxSat_GPP/nc/'
x <- list.files(path)
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/data/lulc/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
outpath <- 'H:/FluxSat_GPP/tif_new/'
for(i in 17:length(x)){
	prebr <- stack(paste0(path,x[i]),varname='GPP')
	for(j in 1:dim(prebr)[3]){
		print(c(i,j))
		dat <- prebr@layers[[j]]
		datvalue <- as.data.frame(dat)[,1]
		datvalue[which(datvalue<=0)]<-NA
		values(dat) <- datvalue
		dvalue <- resample(dat,s,method='bilinear')
		writeRaster(dvalue,paste0(outpath,prebr@z$Date[j],'.tif'),overwrite=T)
	}
}

path <- 'H:/FluxSat_GPP/tif_new/'
outpath <- 'H:/step6/'
x <- list.files(path)
year <- substr(x,1,4)
month <- substr(x,6,7)
day <- substr(x,9,10)
datall <- array(data=NA,dim=c(length(which(lulcid>0)),365*21))
for(i in 1:length(unique(year))){
	print(i)
	seqid <- which(year==unique(year)[i])
	datyear <- array(data=NA,dim=c(length(which(lulcid>0)),366))
	for(j in 1:length(seqid)){
		print(j)
		datyear[,yday(paste0(year[seqid[j]],'-',month[seqid[j]],'-',day[seqid[j]]))]<- as.data.frame(raster(paste0(path,x[seqid[j]])))[which(lulcid>0),1]
	}
	ifelse(leap(as.numeric(year[seqid[j]])),datyear <- datyear[,-60],datyear <- datyear[,-366])
	datall[,((i-1)*365+1):(i*365)] <- datyear%>%as.matrix()
}
write.csv(datall,paste0(outpath,'datall.csv'),row.names=F)

s1bx <- function(x,y){
	x <- as.numeric(x)
	if(length(na.omit(x))<2){
		d2 <- rep(NA,length(x)-y+1)
	}else{
		d1 <- ts(x,frequency=365)%>%stl('periodic')
		d2 <- d1$time.series[,3]%>%funar1(y)
	}
	return(d2)
}
path6 <- 'H:/step6/'
dat <- read.csv(paste0(path6,'datall.csv'),header=T)%>%
			apply(1,fungap,365*21*0.75,'interp')%>%t()
write.csv(dat,paste0(path6,'dat.csv'),row.names=F)

library(dplyr)
library(raster)
library(zoo)
library(forecast)
library(Rfast)
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/data/lulc/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
hot <- as.data.frame(raster('H:/step4/hot.tif'))[which(lulcid>0) ,1]
path6 <- 'H:/step6/'
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
ss <- rep(NA,length(s))
dat <- read.csv(paste0(path6,'dat.csv'),header=T)[which(hot>0),-c(1:182,7482:7665)]
cl <- makeCluster(60)
registerDoParallel(cl)
datAR1 <- foreach(x=1:dim(dat)[1],
			.combine='rbind',
			.export=c("dat","s1bx","fungap"),
			.verbose = TRUE,
			.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
) %dopar% {s1bx(dat[x,],365)}
stopCluster(cl)
write.csv(datAR1,paste0(path6,'datAR1.csv'),row.names=F)

ta_tau <- read.csv('H:/step1/dat_tau.csv',header=T)
sm_tau <- read.csv('H:/step2/dat_tau.csv',header=T)
path6 <- 'H:/step6/'
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
datAR1 <- read.csv(paste0(path6,'datAR1.csv'),header=T)
datallAR1 <- array(data=NA,dim=c(dim(datAR1)[1],floor(dim(datAR1)[2]/365)-1))
for(i in 1:(floor(dim(datAR1)[2]/365)-1)){
	print(i)
	datallAR1[,i] <- datAR1[,((i-1)*365+1):(i*365+365)]%>%
		apply(1,mean,na.rm=T)%>%as.numeric()
}
write.csv(datallAR1,paste0(path6,'datallAR1.csv'),row.names=F)

hot <- as.data.frame(raster('H:/step4/hot.tif'))[,1]
ndd <- c(0, 3, 0, 3, 4, 3, 2, 4, 1, 2, 4, 0, 0, 3, 1, 4, 4, 3,0)[c(1:18)]
path6 <- 'H:/step6/'
lulc <- raster('H:/data/lulc/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA

path6 <- 'H:/step6/'
datallAR1 <- read.csv(paste0(path6,'datallAR1.csv'),header=T)
AR1normal_mean <- apply(datallAR1[,which(ndd=='0')],1,mean,na.rm=T)%>%as.numeric()
AR1E1_2015 <- datallAR1[,15]%>%as.numeric()
AR1E1_mean_2015_dif <- datallAR1[,15]%>%as.numeric()-AR1normal_mean

ss <- rep(NA,length(s))
ss[which(hot>0)] <- AR1normal_mean
values(s) <- ss
writeRaster(s,paste0(path6,'AR1normal_mean.tif'),overwrite=T)

ss <- rep(NA,length(s))
ss[which(hot>0)] <- AR1E1_2015
values(s) <- ss
writeRaster(s,paste0(path6,'AR1E1_2015.tif'),overwrite=T)

ss <- rep(NA,length(s))
ss[which(hot>0)] <- AR1E1_mean_2015_dif
values(s) <- ss
writeRaster(s,paste0(path6,'AR1E1_2015_dif.tif'),overwrite=T)

dat_2015 <- raster("H:/step6/AR1E1_2015_dif.tif")
vals <- getValues(dat_2015)
dateee_2015 <- ifelse(is.na(vals) | vals == 0, NA,
                      ifelse(vals > 0, 1, 2))
classified_2015 <- dat_2015
values(classified_2015) <- dateee_2015
writeRaster(classified_2015, "H:/step6/dateee_2015.tif", overwrite = TRUE)

hot <- as.data.frame(raster('H:/step4/hot.tif'))[,1]
dattj1 <- data.frame(AR1normal_mean=AR1normal_mean,AR1E1_2015=AR1E1_2015, hot=hot[which(hot>0)])
write.csv(dattj1,paste0(path6,'dattj1.csv'),row.names=F)

path6 <- 'H:/step6/'
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
ss <- rep(NA,length(s))
datAR1 <- read.csv(paste0(path6,'datAR1.csv'),header=TRUE)

cl <- makeCluster(60)
registerDoParallel(cl)
slope1 <- foreach(x=1:dim(datAR1)[1],
   .combine='rbind',
   .export=c("datAR1","fun12a","fungap"),
   .verbose = TRUE,
   .packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
) %dopar% {fun12a(datAR1[x,1:(15*365)])}
stopCluster(cl)
write.csv(slope1,paste0(path6,'slope1.csv'),row.names=F)

cl <- makeCluster(60)
registerDoParallel(cl)
slope2 <- foreach(x=1:dim(datAR1)[1],
   .combine='rbind',
   .export=c("datAR1","fun12a","fungap"),
   .verbose = TRUE,
   .packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
) %dopar% {fun12a(datAR1[x,1:(14*365)])}
stopCluster(cl)
write.csv(slope2,paste0(path6,'slope2.csv'),row.names=F)

slope1 <-read.csv("H:/step6/slope1.csv",header=T)
slope2 <-read.csv("H:/step6/slope2.csv",header=T)

hot <- as.data.frame(raster('H:/step4/hot.tif'))[,1]
ss <- rep(NA,length(s))
ss[which(hot>0)] <- slope2[,1]-slope1[,1]
values(s) <- ss
writeRaster(s,paste0(path6,'slope_diff.tif'),overwrite=T)

slope_2015 <- raster("H:/step6/slope_diff.tif")
vals <- getValues(slope_2015)
slope_dif_2015 <- ifelse(is.na(vals) | vals == 0, NA,
                      ifelse(vals < 0, 1, 2))
classified_slope_2015 <- slope_2015
values(classified_slope_2015) <- slope_dif_2015
writeRaster(classified_slope_2015, "H:/step6/slope_2015_classified.tif", overwrite = TRUE)

dattj2 <- data.frame(slope1 = slope1[,1], slope2=slope2[,1], hot=hot[which(hot>0)])
write.csv(dattj2,paste0(path6,'dattj2.csv'),row.names=F)
