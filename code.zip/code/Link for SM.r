# link between ENB and SM (1st path)
library(raster)
library(Kendall)
library(dplyr)
library(zoo)
library(SiZer)
library(stringr)
library(pracma)
library(doSNOW)
library(doParallel)
library(parallel)
path <- 'H:/Gleam/daily3.8/'
x <- list.files(path)
s <- raster(nrow=360,ncol=720)
outpath <- 'H:/DATA/sm/'
for(i in 1:length(x)){
	print(i)
	prebr <- brick(paste0(path,x[i]),varname='SMsurf')
	for(j in 1:dim(prebr)[3]){
		dat <- prebr[[j]]
		datvalue <- as.data.frame(dat)[,1]
		datvalue[which(datvalue<0)]<-NA
		values(dat) <- datvalue
		dvalue <- resample(dat,s,method='bilinear')
		writeRaster(dvalue,paste0(outpath,prebr@data@names[j],'.tif'),overwrite=T)
	}
}

path <- 'H:/DATA/sm/'
outpath <- 'H:/step2/'
x <- list.files(path)[-c(60,1521,2982,4443,5904,7365)]
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
datall <- array(data=NA,dim=c(length(which(lulcid>0)),length(x)))
for(i in 1:length(x)){
	print(i)
	datall[,i] <- as.data.frame(crop(raster(paste0(path,x[i])),lulc))[which(lulcid>0),1]
}
write.csv(datall,paste0(outpath,'datall.csv'),row.names=F)

s2s <- function(x,y){
	out <- fun4a(x, fungap(y,length(x)*0.75,'interp')%>%fun8()%>%as.numeric(),365,200)%>%as.matrix()
	return(out)
}
path2 <- 'H:/step2/'
datall <- read.csv(paste0(path2,'datall.csv'),header=T)[,-c(1:(181+365),7482:7665)]
nino <- read.csv('H:/STEP1/nino.csv',header=T)[,1]
cl <- makeCluster(60)
registerDoParallel(cl)
dat <- foreach(x=1:dim(datall)[1],
				.combine='cbind',
				.export=c("datall","s2s","nino","fun4a","correlation","cor365","fungap"),
				.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
) %dopar% {s2s(nino,datall[x,])}
stopCluster(cl)
write.csv(dat,paste0(path2,'dat.csv'),row.names=F)

path2 <- 'H:/step2/'
dat <- read.csv(paste0(path2,'dat.csv'),header=T)
write.csv(dat[,seq(1,dim(dat)[2],5)],paste0(path2,'dat_c.csv'),row.names=F)
write.csv(dat[,seq(2,dim(dat)[2],5)],paste0(path2,'dat_n.csv'),row.names=F)
write.csv(dat[,seq(3,dim(dat)[2],5)],paste0(path2,'dat_w.csv'),row.names=F)
write.csv(dat[,seq(4,dim(dat)[2],5)],paste0(path2,'dat_tau.csv'),row.names=F)
write.csv(dat[,seq(5,dim(dat)[2],5)],paste0(path2,'dat_thres.csv'),row.names=F)

outpath <- 'H:/step2/'
dat <- read.csv(paste0(outpath,'dat_w.csv'),header=T)
dat_wn <- apply(dat,2,fun11,-1)%>%as.numeric()
dat_wp <- apply(dat,2,fun11,1)%>%as.numeric()
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_wn
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_wn.tif'),overwrite=T)
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_wp
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_wp.tif'),overwrite=T)

outpath <- 'H:/step2/'
dat <- read.csv(paste0(outpath,'dat_c.csv'),header=T)
dat_cn <- apply(dat,2,fun11,-1)%>%as.numeric()
dat_cp <- apply(dat,2,fun11,1)%>%as.numeric()
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_cn
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_cn.tif'),overwrite=T)
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_cp
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_cp.tif'),overwrite=T)

outpath <- 'H:/step2/'
dat <- read.csv(paste0(outpath,'dat_n.csv'),header=T)
dat_nn <- apply(dat,2,fun11a)%>%as.numeric()
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/DATA/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
ss <- rep(NA,length(s))
ss[which(lulcid>0)] <- dat_nn
values(s) <- ss
writeRaster(s,paste0(outpath,'dat_nn.tif'),overwrite=T)
