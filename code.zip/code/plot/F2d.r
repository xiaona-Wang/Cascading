library(tidyverse)
library(ggpubr)
library(scales)
library(patchwork)
library(gghalves)
library(reshape2)
library(purrr)
library(tidyr)
df <- read.csv("H:/step6/dattj2.csv") %>%
  dplyr::select(slope1, slope2, hot) %>%
  melt(id.vars = 'hot') %>%
  na.omit() %>%
  as.data.frame()
df$period <- ifelse(df$variable == "slope2", "0",
             ifelse(df$variable == "slope1", "1", NA))
colnames(df)[3] <- "TAC"
df$hot    <- as.factor(df$hot)
df$period <- as.factor(df$period)
df <- df %>%
  group_by(hot, period) %>%
  filter(TAC >= quantile(TAC, 0.05, na.rm = TRUE)) %>%
  ungroup()
p_values <- df %>%
  group_by(hot) %>%
  nest() %>%
  mutate(
    p.value = map_dbl(data, ~ {
      d <- .
      g0 <- d$TAC[d$period == "0"]
      g1 <- d$TAC[d$period == "1"]
      if (length(g0) > 0 && length(g1) > 0) {
        suppressWarnings(wilcox.test(g0, g1)$p.value)
      } else NA_real_
    }),
    p_label = case_when(
      is.na(p.value)  ~ "p = NA",
      p.value < 0.001 ~ "p < 0.001",
      p.value < 0.01  ~ "p < 0.01",
      p.value < 0.05  ~ "p < 0.05",
      TRUE            ~ "p ≥ 0.05"
    )
  ) %>% select(-data)
x_labs_expr <- c(
  expression(TA^"-" ~ SM^"+"),
  expression(TA^"+" ~ SM^"-"),
  expression(TA^"+" ~ SM^"+"),
  expression(TA^"-" ~ SM^"-")
)
p <- ggplot(df, aes(x = hot, y = TAC, fill = period)) +
  geom_half_violin(
    data = df %>% filter(period == "0"),
    linetype = 1, side = "l",
    alpha = 0.8, adjust = 1.3, trim = TRUE
  ) +
  geom_half_violin(
    data = df %>% filter(period == "1"),
    linetype = 1, side = "r",
    alpha = 0.8, adjust = 1.3, trim = TRUE
  ) +
  geom_point(
    data = df,
    aes(group = period),
    stat = 'summary', fun = mean,
    position = position_dodge(width = 0.4), size = 5
  ) +
  stat_summary(
    data = df, aes(group = period),
    fun.min = function(x) quantile(x, 0.25, na.rm = TRUE),
    fun.max = function(x) quantile(x, 0.75, na.rm = TRUE),
    geom = 'errorbar',
    width = 0.15, size = 1,
    position = position_dodge(width = 0.4)
  ) +
  geom_text(
    data = p_values, aes(x = hot, y = 0.000017, label = p_label),
    size = 9, inherit.aes = FALSE
  ) +
  scale_y_continuous(
    limits = c(-0.00002, 0.00002),
    breaks = seq(-0.00001, 0.00001, by = 0.00001),
    labels = function(x) ifelse(x == 0, "0", format(x, scientific = TRUE))
  ) +
  scale_x_discrete(labels = x_labs_expr) +
  scale_fill_manual(
    values = c("0" = "#004697", "1" = "#CD3800"),
    labels = c("2001-2014", "2001-2015"),
    guide = guide_legend(override.aes = list(shape = NA),
	 direction = "vertical")
  ) +
  labs(y = "Trend in TAC") +
  theme(
    axis.text.x = element_text(
      angle = 0, hjust = 0.5, vjust = 0.5, color = "black",
      size = 27, margin = margin(t = 12)
    ),
    axis.text.y = element_text(
      size = 26, margin = margin(r = 12), color = "black",
      angle = 90, hjust = 0.5, vjust = 0.5
    ),
    axis.title.x = element_blank(),
    axis.title.y = element_text(size = 27),
    panel.background = element_rect(fill = "white", color = NA),
    panel.border = element_rect(fill = NA, color = "black", size = 2, linetype = "solid"),
    legend.key = element_blank(),
    legend.title = element_blank(),
    legend.text = element_text(color = "black", size = 23),
    legend.spacing.x = unit(0.3, 'cm'),
    legend.spacing.y = unit(1.2, 'cm'),
    legend.key.width  = unit(0.8, 'cm'),
    legend.key.height = unit(1.2, 'cm'),
    legend.position = c(0.95, 0.05),
    legend.justification = c(1, -0.3),
    legend.background = element_blank(),
    legend.margin = margin(t = 10, r = 10, b = 10, l = 10),
    axis.ticks = element_line(size = 1.5),
    axis.ticks.length = unit(0.3, "cm")
  )
ggsave("H:/plot/F2d.tif",
       plot = p, device = "tiff", width = 10.25, height = 9.1, dpi = 600)
