library(ggplot2)
library(ggalluvial)
library(dplyr)
library(readr)
library(RColorBrewer)
library(raster)
dat <- as.data.frame(raster('H:/step7/datjz.tif'))[,1]
num <- array()
for(i in 1:32){
	num[i] <- length(which(dat==i))
}
df <- read.csv("H:/output/step7/sum_im.csv",
               header = TRUE, stringsAsFactors = FALSE, fileEncoding = "UTF-8")
df$num <- as.numeric(df$num)
df <- df %>%
    mutate(percentage = round(num / sum(num) * 100, 1))
cols2 <- c(
  "TA↑" = "#59948E",
  "TA↓" = "#8C6A30",
  "SM↑" = "#864B47",
  "SM↓" = "#4E6E94",
  "TAC↑" = "#C94F4F",
  "TAC↓" = "#4F81BD"
)
p <- ggplot(df, aes(axis1 = zone, axis2 = type, axis3 = class, y = percentage)) +
  geom_alluvium(fill = "grey40", alpha = 0.15, size = 0.5) +
  geom_stratum(aes(fill = after_stat(stratum)),
               color = "grey", size = 0.8, width = 0.4) +
  geom_text(stat = "stratum",
            aes(label = after_stat(stratum)),
            family = "Arial", size = 5, color = "black",
            vjust = -0.2) +
  geom_text(stat = "stratum",
            aes(label = paste0(round(after_stat(prop) * 100, 1), "%")),
            family = "Arial", size = 5, color = "black",
            vjust = 1.2) +
  scale_x_discrete(limits = c("Zone", "Type", "Class"), expand = c(-0.2, -0.2)) +
  scale_fill_manual(values = cols2) +
  theme_minimal(base_family = "Arial") +
  theme(
    panel.grid   = element_blank(),
    axis.title   = element_blank(),
    axis.text.x  = element_blank(),
    axis.text.y  = element_blank(),
    axis.ticks   = element_blank(),
    legend.position = "none"
  )
ggsave("H:/plot/F3b.tif", p,
       width = 7, height = 6, dpi = 600, bg = "white")
