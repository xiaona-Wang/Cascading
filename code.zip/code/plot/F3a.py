import os
import numpy as np
import matplotlib.pyplot as plt
import rasterio
from matplotlib.colors import ListedColormap
import geopandas as gpd
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from matplotlib.patches import Patch
folder_path = r'H:/step7'
tif_files = sorted([f for f in os.listdir(folder_path)
                    if f.lower().endswith('.tif') and 'datjz2' in f.lower()])
if not tif_files:
    raise FileNotFoundError(f"not find")
tif_path = os.path.join(folder_path, tif_files[0])
with rasterio.open(tif_path) as src:
    arr = src.read(1, masked=True)
    left, bottom, right, top = src.bounds
shapefile_path = r'H:/data/World_Continents_sub/World_Continents_sub.shp'
world_continents = gpd.read_file(shapefile_path)
if world_continents.crs is not None and world_continents.crs.to_epsg() != 4326:
    world_continents = world_continents.to_crs(epsg=4326)
category_colors = ['#32037D', '#7C1A97', '#C94E65', '#D9995B']
category_cmap = ListedColormap(category_colors)
categories = ['TA/TA', 'TA/SM', 'SM/TA', 'SM/SM']
cat_vals = [1, 2, 3, 4]
fig, ax = plt.subplots(figsize=(10, 8))
world_continents.plot(ax=ax, color='#F5F5F5', linewidth=0.5,
                      edgecolor='#b3b3b3', zorder=0)
im = ax.imshow(
    arr,
    cmap=category_cmap,
    origin='upper',
    extent=[left, right, bottom, top],
    vmin=1, vmax=4,
    interpolation='nearest',
    zorder=1
)
x0, x1 = -170, -120
y0, y1 = -5, 5
rect = plt.Rectangle(
    (x0, y0), x1 - x0, y1 - y0,
    linewidth=1.5,
    facecolor='lightblue',
    zorder=2
)
ax.add_patch(rect)
ax.text(
    (x0 + x1) / 2, (y0 + y1) / 2, 'Niño3.4',
    fontsize=12, color='grey', ha='center', va='center', style='italic',
    bbox=dict(facecolor='none', edgecolor='none',boxstyle='round,pad=0.2'),
    zorder=3
)
ax.set_title("Cascading mechanism in El Niño-resilience chain", fontsize=16)
ax.set_xticks([])
ax.set_yticks([])
vals = arr.compressed() if np.ma.isMaskedArray(arr) else arr.ravel()
category_counts = [int(np.sum(vals == v)) for v in cat_vals]
total_pixels = sum(category_counts)
category_percentages = [(c / total_pixels * 100) if total_pixels > 0 else 0.0
                        for c in category_counts]
ax_inset = inset_axes(
    ax, width="25%", height="23%", loc='lower left',
    bbox_to_anchor=(0.02, 0.08, 1, 1), bbox_transform=ax.transAxes
)
bars = ax_inset.bar(categories, category_percentages, color=category_colors)
ax_inset.tick_params(axis='x', labelsize=10)
ax_inset.tick_params(axis='y', which='both', left=False, right=False, labelleft=False)
top_y = max(category_percentages) * 1.12 if total_pixels > 0 else 1.0
ax_inset.set_ylim(0, top_y)
for spine in ['top', 'right', 'left']:
    ax_inset.spines[spine].set_visible(False)
for bar in bars:
    h = bar.get_height()
    ax_inset.text(bar.get_x() + bar.get_width() / 2, h, f'{h:.1f}%', ha='center', va='bottom', fontsize=10)
output_path = r'H:/plot/F3a.tif'
os.makedirs(os.path.dirname(output_path), exist_ok=True)
fig.savefig(output_path, dpi=600, bbox_inches='tight')
plt.show()
