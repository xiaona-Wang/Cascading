import os
import numpy as np
import matplotlib.pyplot as plt
import rasterio
from matplotlib.colors import ListedColormap
import geopandas as gpd
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from matplotlib.ticker import FuncFormatter
folder_path = r'H:/step6'
tif_files = sorted([f for f in os.listdir(folder_path) if f.endswith('.tif') and 'dateee_2015' in f])
if not tif_files:
    raise FileNotFoundError("not find")
tif_data = []
for tif_file in tif_files:
    tif_path = os.path.join(folder_path, tif_file)
    with rasterio.open(tif_path) as src:
        arr = src.read(1, masked=True)
        tif_data.append(arr)
shapefile_path = r'H:/data/World_Continents_sub/World_Continents_sub.shp'
world_continents = gpd.read_file(shapefile_path)
if world_continents.crs is not None and world_continents.crs.to_epsg() != 4326:
    world_continents = world_continents.to_crs(epsg=4326)
category_colors = ['#CD3800', '#004697']
category_cmap = ListedColormap(category_colors)
fig, ax = plt.subplots(figsize=(10, 8))
world_continents.plot(ax=ax, color='#F5F5F5', linewidth=0.5, edgecolor='#b3b3b3', zorder=0)
im = ax.imshow(
    tif_data[0],
    cmap=category_cmap,
    origin='upper',
    extent=[-180, 180, -60, 83],
    vmin=1, vmax=2,
    interpolation='nearest',
    zorder=1
)
lonlat_coords = np.array([[-170, -5], [-120, 5]])
x = lonlat_coords[:, 0]
y = lonlat_coords[:, 1]
rect = plt.Rectangle(
    (x[0], y[0]),
    x[1] - x[0],
    y[1] - y[0],
    linewidth=1.5,
    facecolor='lightblue',
    zorder=2
)
ax.add_patch(rect)
text_x = float(np.mean(x))
text_y = float(np.mean(y))
ax.text(
    text_x, text_y, 'Niño3.4',
    fontsize=12, color='grey', ha='center', va='center', style='italic',
    bbox=dict(facecolor='none', edgecolor='none', boxstyle='round,pad=0.2'),
    zorder=3
)
ax.set_title("ΔTAC during 2015/2016 El Niño", fontsize=16)
def lon_fmt(x, _pos):
    hemi = 'E' if x >= 0 else 'W'
    val = abs(round(x))
    return f"{val}°{hemi}"
def lat_fmt(y, _pos):
    hemi = 'N' if y >= 0 else 'S'
    val = abs(round(y))
    return f"{val}°{hemi}"
ax.xaxis.set_major_formatter(FuncFormatter(lon_fmt))
ax.yaxis.set_major_formatter(FuncFormatter(lat_fmt))
arr0 = tif_data[0]
valid = ~arr0.mask if np.ma.isMaskedArray(arr0) else np.ones_like(arr0, dtype=bool)
arr_valid = arr0.data[valid] if np.ma.isMaskedArray(arr0) else arr0[valid]
categories = ['POS', 'NEG']
cat_vals = [1, 2]
category_counts = [np.sum(arr_valid == v) for v in cat_vals]
total_pixels = int(np.sum(category_counts))
category_percentages = [(c / total_pixels * 100) if total_pixels > 0 else 0.0 for c in category_counts]
ax_inset = inset_axes(
    ax, width="18%", height="20%", loc='lower left',
    bbox_to_anchor=(0.02, 0.08, 1, 1), bbox_transform=ax.transAxes
)
x_pos = [0.4, 0.8]
bar_width = 0.35
bars = ax_inset.bar(x_pos, category_percentages, color=category_colors, width=bar_width)
ax_inset.set_xticks(x_pos, categories)
ax_inset.set_yticks([])
ax_inset.tick_params(axis='y', left=False, right=False)
for spine in ['top', 'right', 'left']:
    ax_inset.spines[spine].set_visible(False)
for bar in bars:
    h = bar.get_height()
    ax_inset.text(bar.get_x() + bar.get_width() / 2, h, f'{h:.1f}%', ha='center', va='bottom', fontsize=9)
output_path = r'H:/plot/F2a.tif'
fig.savefig(output_path, dpi=600, bbox_inches='tight')
plt.show()
