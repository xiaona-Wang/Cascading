import os
import numpy as np
import matplotlib.pyplot as plt
import rasterio
from matplotlib.colors import ListedColormap
import geopandas as gpd
from matplotlib.ticker import FuncFormatter
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
folder_path = r'H:/step6'
tif_files = sorted([f for f in os.listdir(folder_path)
                    if f.lower().endswith('.tif') and 'slope_2015_classified' in f])
if not tif_files:
    raise FileNotFoundError("not find")
tif_path = os.path.join(folder_path, tif_files[0])
with rasterio.open(tif_path) as src:
    arr = src.read(1, masked=True)
shapefile_path = r'H:/data/World_Continents_sub/World_Continents_sub.shp'
world_continents = gpd.read_file(shapefile_path)
if world_continents.crs is not None and world_continents.crs.to_epsg() != 4326:
    world_continents = world_continents.to_crs(epsg=4326)
category_colors = ['#CD3800', '#004697']
category_cmap = ListedColormap(category_colors)
fig, ax = plt.subplots(figsize=(10, 8))
world_continents.plot(ax=ax, color='#F5F5F5', linewidth=0.5, edgecolor='#b3b3b3', zorder=0)
im = ax.imshow(
    arr,
    cmap=category_cmap,
    origin='upper',
    extent=[-180, 180, -60, 83],
    vmin=1, vmax=2,
    interpolation='nearest',
    zorder=1
)
x0, x1 = -170, -120
y0, y1 = -5, 5
rect = plt.Rectangle(
    (x0, y0), x1 - x0, y1 - y0,
    linewidth=1.5,
    facecolor='lightblue',
    zorder=2
)
ax.add_patch(rect)
ax.text(
    (x0 + x1) / 2, (y0 + y1) / 2, 'Niño3.4',
    fontsize=12, color='grey', ha='center', va='center', style='italic',
    bbox=dict(facecolor='none', edgecolor='none', boxstyle='round,pad=0.2'),
    zorder=3
)
ax.set_title("Changes in TAC trend", fontsize=16)
def lon_fmt(val, _pos):
    hemi = 'E' if val >= 0 else 'W'
    return f"{abs(int(round(val)))}°{hemi}"
def lat_fmt(val, _pos):
    hemi = 'N' if val >= 0 else 'S'
    return f"{abs(int(round(val)))}°{hemi}"
ax.xaxis.set_major_formatter(FuncFormatter(lon_fmt))
ax.yaxis.set_major_formatter(FuncFormatter(lat_fmt))
vals = arr.compressed() if np.ma.isMaskedArray(arr) else arr.ravel()
categories = ['POS', 'NEG']
cat_vals = [1, 2]
category_counts = [int(np.sum(vals == v)) for v in cat_vals]
total_pixels = sum(category_counts)
category_percentages = [(c / total_pixels * 100) if total_pixels > 0 else 0.0
                        for c in category_counts]
ax_inset = inset_axes(
    ax, width="18%", height="20%", loc='lower left',
    bbox_to_anchor=(0.02, 0.08, 1, 1), bbox_transform=ax.transAxes
)
x_pos = [0.4, 0.8]
bar_width = 0.35
bars = ax_inset.bar(x_pos, category_percentages, color=category_colors, width=bar_width)
ax_inset.set_xticks(x_pos, categories)
ax_inset.set_yticks([])
ax_inset.tick_params(axis='y', which='both', left=False, right=False)
for spine in ['top', 'right', 'left']:
    ax_inset.spines[spine].set_visible(False)
for bar in bars:
    h = bar.get_height()
    ax_inset.text(bar.get_x() + bar.get_width() / 2, h, f'{h:.1f}%',
                  ha='center', va='bottom', fontsize=9)
output_path = r'H:/plot/F2c.tif'
fig.savefig(output_path, dpi=600, bbox_inches='tight')
plt.show()
