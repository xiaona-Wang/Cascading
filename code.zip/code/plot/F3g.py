import rasterio
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
from cartopy.feature import LAND
import pandas as pd
def make_map(ax):
    ax.coastlines(resolution='50m')
    ax.gridlines(draw_labels=False, linewidth=1.5, color='gray', alpha=0.5, linestyle='--')
    return ax
u_path = 'H:/step8/eu.tif'
v_path = 'H:/step8/ev.tif'
u_dataset = rasterio.open(u_path)
v_dataset = rasterio.open(v_path)
lon_min, lat_min, lon_max, lat_max = u_dataset.bounds
lon = np.linspace(lon_min, lon_max, u_dataset.width)
lat = np.linspace(lat_min, lat_max, u_dataset.height)
u = u_dataset.read(1)
v = v_dataset.read(1)
w = np.sqrt(u**2 + v**2)
fig = plt.figure(figsize=(10, 10))
#bm
#proj = ccrs.Orthographic(central_longitude=-120, central_latitude=10)
#nm
#proj = ccrs.Orthographic(central_longitude=-120, central_latitude=-10)
#tp
proj = ccrs.Orthographic(central_longitude=135, central_latitude=20)
ax = fig.add_subplot(1, 1, 1, projection=proj)  # Use only one subplot
ax.set_global()
ax.add_feature(LAND, edgecolor='black')
x, y = np.meshgrid(lon, lat)
ax.quiver(x[::3, ::3], y[::3, ::3], u[::3, ::3], v[::3, ::3], pivot='mid',
          width=0.003, scale_units='inches', scale=20, transform=ccrs.PlateCarree(),
          color='white', angles='xy', zorder=1)
ax.contourf(lon, lat, w, zorder=0, transform=ccrs.PlateCarree(), cmap='GnBu',
           levels=np.arange(0, 21, 2), extend='both')
make_map(ax)
#bm
#csv_path = 'H:/step8/bm/dat_1_1299.csv'
#nm
#csv_path = 'H:/step8/nm/dat_3_1299.csv'
#tp
csv_path = 'H:/step8/tp/dat_1_1299.csv'
coordinates = pd.read_csv(csv_path)
lon_points = coordinates['lon'].values
lat_points = coordinates['lat'].values
points = proj.transform_points(ccrs.PlateCarree(), np.array(lon_points), np.array(lat_points))
lon_points_proj, lat_points_proj = points[:, 0], points[:, 1]
for i in range(len(lon_points_proj) - 1):
    ax.annotate('', xy=(lon_points_proj[i+1], lat_points_proj[i+1]),
                 xytext=(lon_points_proj[i], lat_points_proj[i]),
                 arrowprops=dict(arrowstyle='->', color='#CD2626', lw=6))
output_path = 'H:/plot/e_tp.tif'
plt.savefig(output_path, bbox_inches='tight', pad_inches=0.1, dpi=600)
plt.show()
