# cascading strength
library(raster)
library(Kendall)
library(dplyr)
library(zoo)
library(SiZer)
library(stringr)
library(pracma)
library(doSNOW)
library(doParallel)
library(forecast)
s2s <- function(x,y){
	x <- as.numeric(x);y <- as.numeric(y)
	if(length(na.omit(x))=='0' | length(na.omit(y))=='0'){
		out <- array(data=NA,dim=c(18,5))
	}else{
	out<- fun4a(x%>%na.interp()%>%fun8()%>%as.numeric(),y,365,200)%>%as.matrix()
	}
	return(out)
}
path7 <- 'H:/step7/'
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/data/lulc/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
hot <- as.data.frame(raster('H:/step4/hot.tif'))[which(lulcid>0),1]
dat1all <- read.csv(paste0('/H:/step1/datall.csv'),header=T)[which(hot>0),-c(1:(181+365),7482:8395)]
datAR1 <- read.csv(paste0('H:/step6/datAR1.csv'),header=T)
cl <- makeCluster(60)
registerDoParallel(cl)
dat_ta <- foreach(x=1:dim(datAR1)[1],
				.combine='cbind',
				.export=c("datAR1","dat1all","s2s","fun4a","correlation","cor365","na.interp"),
				.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
) %dopar% {s2s(dat1all[x,],datAR1[x,])}
stopCluster(cl)
write.csv(dat_ta,paste0(path7,'dat_ta.csv'),row.names=F)

dat2all <- read.csv(paste0('H:/step2/datall.csv'),header=T)[which(hot>0),-c(1:(181+365),7482:8395)]
cl <- makeCluster(60)
registerDoParallel(cl)
dat_swc <- foreach(x=1:dim(datAR1)[1],
				.combine='cbind',
				.export=c("datAR1","dat2all","s2s","fun4a","correlation","cor365","na.interp"),
				.packages=c("zoo","dplyr","doParallel","doSNOW","parallel","forecast")
) %dopar% {s2s(dat2all[x,],datAR1[x,])}
stopCluster(cl)
write.csv(dat_swc,paste0(path7,'dat_swc.csv'),row.names=F)

path7 <- 'H:/step7/'
datw_swc <- dat_swc[,seq(3,dim(dat_swc)[2],5)]
datw_ta <- dat_ta[,seq(3,dim(dat_ta)[2],5)]
write.csv(datw_swc,paste0(path7,'datw_swc.csv'),row.names=F)
write.csv(datw_ta,paste0(path7,'datw_ta.csv'),row.names=F)

path1 <- 'H:/step1/'
path2 <- 'H:/step2/'
s <- raster(nrow=286,ncol=720)
extent(s) <- c(-180, 180, -60, 83)
lulc <- raster('H:/data/lulc/Ecoregion2017.tif')%>%crop(s)
lulcid <- as.data.frame(lulc)[,1]
lulcid[which(lulcid=='11')]<-NA
hot <- as.data.frame(raster('H:/step4/hot.tif'))[,1]
dat_ta_s1p <- as.data.frame(raster(paste0(path1,'dat_wp.tif')))[which(hot>0),1]
dat_ta_s1n <- as.data.frame(raster(paste0(path1,'dat_wn.tif')))[which(hot>0),1]
dat_swc_s1p <- as.data.frame(raster(paste0(path2,'dat_wp.tif')))[which(hot>0),1]
dat_swc_s1n <- as.data.frame(raster(paste0(path2,'dat_wn.tif')))[which(hot>0),1]
path7 <- 'H:/step7/'
datw_swc <- read.csv(paste0(path7,'datw_swc.csv'),header=T)
datw_ta <- read.csv(paste0(path7,'datw_ta.csv'),header=T)
datw_swc_s2p <- apply(datw_swc,2,fun11,1)%>%as.numeric()
datw_swc_s2n <- apply(datw_swc,2,fun11,-1)%>%as.numeric()
datw_ta_s2p <- apply(datw_ta,2,fun11,1)%>%as.numeric()
datw_ta_s2n <- apply(datw_ta,2,fun11,-1)%>%as.numeric()
dats1 <- data.frame(s1=dat_ta_s1p,s2=dat_ta_s1n,s3=dat_swc_s1p,s4=dat_swc_s1n)%>%
						fun17a(hot[which(hot>0)])%>%apply(1,fun17)%>%t()
dats3 <- data.frame(s1=dat_ta_s1p,s2=dat_ta_s1n,
						s3=dat_swc_s1p,s4=dat_swc_s1n)%>%
						fun17a(hot[which(hot>0)])%>%apply(1,fun17c)%>%t()
dats2 <- data.frame(s1=datw_ta_s2p,s2=datw_ta_s2n,
						s3=datw_swc_s2p,s4=datw_swc_s2n)%>%
						apply(1,fun17)%>%t()
datsall <- data.frame(s1_ta_p=dat_ta_s1p,s1_ta_n=dat_ta_s1n,s1_swc_p=dat_swc_s1p,s1_swc_n=dat_swc_s1n,
						s2_ta_p=datw_ta_s2p,s2_ta_n=datw_ta_s2n,s2_swc_p=datw_swc_s2p,s2_swc_n=datw_swc_s2n,
						dats1,dats2,s1_min=dats3[,2],hot=hot[which(hot>0)])
y1 <- c('TAnSMp','TApSMn','TApSMp','TAnSMn')
y2 <- c('TAp','TAn','SMp','SMn')
datu1 <- array();datu2 <- array();
for(ii in 1:dim(datsall)[1]){
	if(is.na(datsall$X1[ii])){
		datu1[ii] <- NA;datu2[ii] <- NA
	}else if(datsall$X1[ii]=='1'){
		datu1[ii] <- substr(y1[datsall$hot][ii],1,3)
		datu2[ii] <- substr(y1[datsall$hot][ii],4,6)
	}else if(datsall$X1[ii]=='2'){
		datu1[ii] <- substr(y1[datsall$hot][ii],4,6)
		datu2[ii] <- substr(y1[datsall$hot][ii],1,3)
	}
}
datsall$y1 <- datu1
datsall$y2 <- datu2
write.csv(datsall,'H:/step7/datsall.csv',row.names=F)

datsall <- read.csv('H:/step7/datsall.csv',header=T)
hot <- as.data.frame(raster('H:/step4/hot.tif'))[,1]
y1 <- c('TAnSMp','TApSMn','TApSMp','TAnSMn')
y2 <- c('TAp','TAn','SMp','SMn')
y3 <- c('TACup','TACdown')
for(i in 1:4){
for(j in 1:4){
	s1 <- subset(datsall,y1==na.omit(unique(datsall$y1))[i] & X1.1==j)
	for(k in 1:length(unique(s1$y2))){
		t1 <- s1[which(s1$y2==unique(s1$y2)[k]),]
		s1a <- rownames(t1)%>%as.numeric()
		s1b <- t1$X2*t1$X2.1
		ss1 <- rep(NA,dim(datsall)[1])
		ss1[s1a] <- s1b
		ss <- rep(NA,length(hot))
		ss[which(hot>0)] <- ss1
		values(s)<- ss
		writeRaster(s,paste0('H:/step7/32/',na.omit(unique(datsall$y1))[i],
					"_",unique(s1$y2)[k],"_",
					y2[j],'.tif'),overwrite=T)
	}
}}

x <- list.files('H:/step7/32/',pattern='.tif')
datsst <- array(data=NA,dim=c(205920,length(x)))
for(i in 1:length(x)){
	dat <- as.data.frame(raster(paste0('H:/step7/32/',x[i])))[,1]
	dat[which(dat>0)] <- i
	datsst[,i] <- dat
}
datjz <- apply(datsst,1,sum,na.rm=T)%>%as.numeric()
datjz[which(datjz=='0')] <- NA
values(s) <- datjz
writeRaster(s,'H:/step7/datjz.tif',overwrite=T)
datjz <- as.data.frame(raster('H:/step7/datjz.tif'))[,1]
c1 <- c(23,28,32,19,24,27,31,20)
c2 <- c(22,25,30,17,21,26,29,18)
c3 <- c(11,8,16,3,12,7,15,4)
c4 <- c(10,5,14,1,9,6,13,2)
datjz2 <- array()
for(i in 1:length(datjz)){
	if(is.na(datjz[i])){
		datjz2[i] <- NA
	}else if(datjz[i] %in% c1){datjz2[i] <- 1
	}else if(datjz[i] %in% c2){datjz2[i] <- 2
	}else if(datjz[i] %in% c3){datjz2[i] <- 3
	}else if(datjz[i] %in% c4){datjz2[i] <- 4}
}
values(s) <- datjz2
writeRaster(s,'H:/step7/datjz2.tif',overwrite=T)

datsall <- read.csv('H:/step7/datsall.csv',header=T)
hot <- as.data.frame(raster('H:/step4/hot.tif'))[,1]
ss <- rep(NA,length(hot))
ss[which(hot>0)] <- datsall$X2*datsall$X2.1
datsall$value <- datsall$X2*datsall$X2.1
values(s)<- ss
writeRaster(s,'H:/step7/value.tif',overwrite=T)

path4 <- 'H:/step4/'
hotall <- as.data.frame(raster(paste0(path4,'hot.tif')),xy=T)
hot <- as.data.frame(raster('H:/step4/hot.tif'))[,1]
hotall <- hotall[which(hot>0),]
dis <- array()
for(i in 1:dim(hotall)[1]){
print(i)
dis[i] <- fundis(-150,0,hotall[i,1],hotall[i,2])/1000
}
datsall$dis <- dis
write.csv(datsall,'H:/step7/datsall_dis.csv',row.names=F)
dat <- data.frame(lat=hotall$y,qd=datsall$value)
write.csv(dat,'H:/step7/dat_tj1.csv',row.names=F)
qdlat1 <- array();qdlat2 <- array();
for(i in 1:180){
	qdlat1[i] <- median(dat$qd[which(hotall[,2]>(-90+i-1) & hotall[,2]<(-90+i))],na.rm=T)
	qdlat2[i] <- 0.5*sd(dat$qd[which(hotall[,2]>(-90+i-1) & hotall[,2]<(-90+i))],na.rm=T)
}
dattj2 <- data.frame(qdlat1=qdlat1,qdlat2=qdlat2,lat=seq(-89.5,89.5,1))
write.csv(dattj2,'H:/step7/dat_tj2.csv',row.names=F)
